"""Versioned direct-mass analysis and forward comparison to independent VED."""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from analysis import read_runs
from continuation import bin_kernel
from direct_mass import fit_direct_mass,mass_curve
from spectral_cv import whitening


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',required=True)
    args=parser.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
    summary={}
    dispersion=json.loads((ROOT/'results/mass/summary.json').read_text())
    for coupling in [.25,.5]:
        label=f'lambda{coupling:.2f}_k0.00_base'
        runs=sorted(p for p in (ROOT/'results/k0_01').glob(label+'_s*') if p.is_dir())
        rows,owners,metas=read_runs(runs);p=metas[0]
        fits=[fit_direct_mass(rows,owners,p,start,20) for start in [4.,6.,8.,10.,12.]]
        curve,error=mass_curve(rows,owners,p)
        tau=(np.arange(p['bins'])+.5)*p['tau_max']/p['bins']
        np.savez_compressed(out/f'mass_lambda{coupling:.2f}.npz',tau=tau,curvature=curve,error=error)
        checks={}
        ref=np.load(ROOT/f'results/reference_spectral_01/lambda{coupling:.2f}_nh18_steps1000.npz')
        for estimator in ['analysis','conditional']:
            source=ROOT/'results/spectral_data_01'/estimator/label
            meta=json.loads((source/'summary.json').read_text())['parameters']
            data=np.load(source/'green.npz');tau,G,C=(data[k] for k in ['tau','G','covariance'])
            expected=bin_kernel(tau,meta['tau_max']/meta['bins'],ref['energies'],meta['mu'])@ref['weights']
            error=np.sqrt(np.diag(C))
            modes=[]
            for tolerance in [1e-4,1e-6,1e-8,1e-10]:
                W=whitening(G,C,tolerance);residual=W@(G-expected)
                modes.append(dict(tolerance=tolerance,rank=len(W),chi2_per_mode=float(residual@residual/len(W))))
            checks[estimator]=dict(max_bin_sigma=float(max(abs(G-expected)/error)),
                rms_bin_sigma=float(np.sqrt(np.mean(((G-expected)/error)**2))),covariance_scan=modes,
                source_sha256=sha256((source/'green.npz').read_bytes()).hexdigest())
            np.savez_compressed(out/f'forward_{estimator}_lambda{coupling:.2f}.npz',tau=tau,G=G,error=error,expected=expected)
        summary[str(coupling)]=dict(direct_mass=fits[1],fit_windows=fits,
            dispersion_mass=dispersion[str(coupling)]['primary'],forward_checks=checks)
        print(coupling,summary[str(coupling)],flush=True)
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    sources=[Path(__file__),ROOT/'direct_mass.py',ROOT/'analysis.py']
    (out/'sources.json').write_text(json.dumps({str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in sources},indent=2)+'\n')

if __name__=='__main__':main()
