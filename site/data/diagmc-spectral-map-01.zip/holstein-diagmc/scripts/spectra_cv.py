"""Independent-chain cross validation of the conditional-estimator spectra."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from analysis import estimate_green
from continuation import broaden
from spectral_cv import reconstruct_scan,evaluate,prior_covariance

out=ROOT/'results/spectral_02'
out.mkdir(exist_ok=False)
summary={}
alphas=np.logspace(-6,6,25)
axis=np.linspace(-3.25,7,1601);eta=.25
for coupling in [.25,.5]:
    base=ROOT/'results/k0_01/analysis'/f'lambda{coupling:.2f}_k0.00_base'
    baseline=json.loads((base/'summary.json').read_text())
    prior=np.array([baseline['primary'][key] for key in ['E','Z']])
    prior_cov=prior_covariance(baseline,np.load(base/'green.npz'))
    source=ROOT/'results/spectral_data_01/conditional'/f'lambda{coupling:.2f}_k0.00_base'
    meta=json.loads((source/'summary.json').read_text());p=meta['parameters']
    saved=np.load(source/'green.npz');tau,G,C,blocks,owners=(saved[k] for k in ['tau','G','covariance','blocks','owners'])
    cv=[]
    for owner in np.unique(owners):
        train,train_cov,_=estimate_green(blocks[owners!=owner],p)
        test,test_cov,_=estimate_green(blocks[owners==owner],p)
        fitted=reconstruct_scan(tau,train,train_cov,p,prior,prior_cov,alphas)
        cv.append([evaluate(tau,test,test_cov,p,fitted['omega'],f) for f in fitted['fits']])
    cv=np.asarray(cv);mean=cv.mean(axis=0);se=cv.std(axis=0,ddof=1)/np.sqrt(len(cv))
    best=int(np.argmin(mean))
    acceptable=np.flatnonzero(mean<=mean[best]+se[best])
    selected=int(acceptable[-1])
    fitted=reconstruct_scan(tau,G,C,p,prior,prior_cov,alphas)
    chosen=fitted['fits'][selected]
    spectrum,rest=broaden(axis,fitted['omega'],chosen['weights'],chosen['E'],chosen['Z'],eta)
    sensitivity=[broaden(axis,fitted['omega'],fitted['fits'][i]['weights'],
                         fitted['fits'][i]['E'],fitted['fits'][i]['Z'],eta) for i in acceptable]
    scans=[]
    for cutoff,size,tolerance in [(8.,120,1e-8),(16.,240,1e-8),(12.,240,1e-8),
                                  (12.,180,1e-6),(12.,180,1e-10)]:
        trial=reconstruct_scan(tau,G,C,p,prior,prior_cov,[chosen['alpha']],cutoff,size,tolerance)
        f=trial['fits'][0]
        curves=broaden(axis,trial['omega'],f['weights'],f['E'],f['Z'],eta)
        curve=curves[0];sensitivity.append(curves)
        scans.append(dict(cutoff=cutoff,size=size,tolerance=tolerance,rank=f['rank'],
                          chi2_per_mode=f['chi2_per_mode'],
                          l1_change=float(np.trapezoid(abs(curve-spectrum),axis)/np.trapezoid(spectrum,axis))))
    rng=np.random.default_rng(619103+round(coupling*100))
    values,vectors=np.linalg.eigh(C);root=vectors*np.sqrt(np.maximum(values,0))
    noise=[]
    for _ in range(24):
        noisy_G=G+root@rng.normal(size=len(tau))
        noisy_prior=rng.multivariate_normal(prior,prior_cov)
        trial=reconstruct_scan(tau,noisy_G,C,p,noisy_prior,prior_cov,[chosen['alpha']])
        f=trial['fits'][0]
        noise.append(broaden(axis,trial['omega'],f['weights'],f['E'],f['Z'],eta))
    low,high=np.quantile(noise,[.16,.84],axis=0)
    sensitivity=np.asarray(sensitivity)
    # Benchmark access starts only AFTER fitting and choosing regularization.
    reference_dir=ROOT/'results/reference_spectral_01'
    def reference(nh,steps):
        pole=np.load(reference_dir/f'lambda{coupling:.2f}_nh{nh}_steps{steps}.npz')
        return (eta/np.pi/((axis[:,None]-pole['energies'][None,:])**2+eta**2))@pole['weights']
    ref=reference(18,1000)
    refs=json.loads((reference_dir/'summary.json').read_text())
    info=next(r for r in refs if r['coupling']==coupling and r['generations']==18)
    refrest=ref-info['Z']*eta/np.pi/((axis-info['E'])**2+eta**2)
    denominator=np.trapezoid(ref,axis);rest_denominator=np.trapezoid(refrest,axis)
    reference_scan=[]
    for nh,steps in [(14,1000),(16,1000),(18,500)]:
        curve=reference(nh,steps)
        reference_scan.append(dict(generations=nh,steps=steps,
            spectral_l1=float(np.trapezoid(abs(curve-ref),axis)/denominator),
            rest_l1=float(np.trapezoid(abs(curve-ref),axis)/rest_denominator)))
    np.savez_compressed(out/f'lambda{coupling:.2f}.npz',axis=axis,A=spectrum,rest=rest,reference=ref,
        reference_rest=refrest,noise_low=low[0],noise_high=high[0],
        noise_rest_low=low[1],noise_rest_high=high[1],sensitivity_low=sensitivity[:,0,:].min(axis=0),
        sensitivity_high=sensitivity[:,0,:].max(axis=0),sensitivity_rest_low=sensitivity[:,1,:].min(axis=0),
        sensitivity_rest_high=sensitivity[:,1,:].max(axis=0),energies=fitted['omega'],weights=chosen['weights'],
        tau=tau,G=G,G_error=np.sqrt(np.diag(C)),G_fit=chosen['predicted'])
    public_fit=lambda f:{key:value for key,value in f.items() if key not in ['weights','predicted']}
    summary[str(coupling)]=dict(eta=eta,selected=public_fit(chosen),prior=prior.tolist(),
        prior_covariance=prior_cov.tolist(),cv_folds=cv.tolist(),cv_mean=mean.tolist(),cv_se=se.tolist(),
        alphas=alphas.tolist(),best_cv_alpha=float(alphas[best]),
        selected_alpha=float(alphas[selected]),acceptable_alphas=alphas[acceptable].tolist(),
        selection='largest alpha within one standard error of the best held-out-chain score',
        alpha_boundary=bool(selected in [0,len(alphas)-1]),regularization_scan=[public_fit(f) for f in fitted['fits']],
        grid_covariance_scan=scans,noise_replicates=len(noise),reference_scan=reference_scan,
        spectral_l1_vs_reference=float(np.trapezoid(abs(spectrum-ref),axis)/denominator),
        rest_l1_vs_reference=float(np.trapezoid(abs(rest-refrest),axis)/rest_denominator),
        status='coarse regularized spectrum; fine structure and individual excited peaks unresolved',
        input_sha256=sha256((source/'green.npz').read_bytes()).hexdigest())
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(coupling,{k:v for k,v in summary[str(coupling)].items() if k in
        ['selected','selected_alpha','spectral_l1_vs_reference','rest_l1_vs_reference','reference_scan']},flush=True)
(out/'source_hashes.json').write_text(json.dumps({name:sha256((ROOT/name).read_bytes()).hexdigest()
    for name in ['continuation.py','spectral_cv.py','scripts/spectra_cv.py']},indent=2)+'\n')
