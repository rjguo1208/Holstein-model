"""Create standalone scientific figures and a Chinese report from saved data."""
from __future__ import annotations
import json
from pathlib import Path
import sys
import numpy as np
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from analysis import read_runs,combine_blocks,jackknife_error

def read(name): return json.loads((ROOT/'results'/name).read_text())
base=read('k0_01/summary.json');mass=read('mass/summary.json')
spectral=read('spectral_02/summary.json');refs=read('reference_01/reference.json')
controls=read('controls_01/summary.json')
out=ROOT/'results/report';out.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,
                    'axes.spines.right':False,'mathtext.fontset':'dejavuserif','svg.fonttype':'path',
                    'figure.constrained_layout.use':True,'savefig.dpi':180})
blue='#205a85';gray='#666666'

def save(fig,name):
    for extension in ['svg','pdf','png']: fig.savefig(out/f'{name}.{extension}')
    plt.close(fig)

fig,axes=plt.subplots(2,2,figsize=(9,6))
for column,lam in enumerate([.25,.5]):
    data=base[f'lambda{lam:.2f}_k0.00_base'];p=data['parameters'];primary=data['primary']
    source=ROOT/'results/k0_01/analysis'/f'lambda{lam:.2f}_k0.00_base'
    stored=np.load(source/'green.npz');tau,G,C=(stored[k] for k in ['tau','G','covariance'])
    ax=axes[0,column]
    ax.errorbar(tau,G,np.sqrt(np.diag(C)),fmt='.',ms=3,color=blue,label='Bare DiagMC')
    ax.plot(tau,primary['Z']*np.exp(-(primary['E']-p['mu'])*tau),color=gray,label='Long-time fit')
    ax.axvspan(6,20,color='0.95',zorder=-1);ax.set_yscale('log')
    ax.set(title=rf'$\lambda={lam}$',xlabel=r'$\tau t$',ylabel=r'$\mathcal{G}_\mu(0,\tau)$')
    if column==0: ax.legend(frameon=False,fontsize=8)
    paths=[ROOT/'results/k0_01'/Path(path).name for path in data['runs']]
    rows,owners,metas=read_runs(paths);grouped=combine_blocks(rows,owners,4)
    jack=grouped.sum(axis=0)[None,:]-grouped;n=p['bins'];factor=4
    def effective(a):
        count=a[...,3:3+n].reshape(*a.shape[:-1],n//factor,factor).sum(axis=-1)
        energy=a[...,3+n:3+2*n].reshape(*a.shape[:-1],n//factor,factor).sum(axis=-1)
        return energy/count
    e=effective(grouped.sum(axis=0));error=jackknife_error(effective(jack))
    t=(np.arange(n//factor)+.5)*p['tau_max']/(n//factor)
    reference=next(r for r in refs if r['coupling']==lam and r['generations']==16)
    ax=axes[1,column]
    ax.errorbar(t,e,error,fmt='o',ms=3,color=blue,label='Energy estimator')
    ax.axhline(reference['E'],color=gray,ls='--',label='VED reference')
    ax.set(xlabel=r'$\tau t$',ylabel=r'$E_{\rm eff}(\tau)/t$',xlim=(3,24),
           ylim=(reference['E']-.008,reference['E']+.012))
    if column==0: ax.legend(frameon=False,fontsize=8)
save(fig,'green')

fig,axes=plt.subplots(2,2,figsize=(9,6))
for column,lam in enumerate([.25,.5]):
    data=base[f'lambda{lam:.2f}_k0.00_base']
    reference=next(r for r in refs if r['coupling']==lam and r['generations']==16)
    for row,observable in enumerate(['E','Z']):
        ax=axes[row,column];fits=data['fit_windows']
        ax.errorbar([f['tau_min'] for f in fits],[f[observable] for f in fits],
                    [f[observable+'_error'] for f in fits],fmt='o',capsize=3,color=blue)
        ax.axhline(reference[observable],color=gray,ls='--',label='VED reference')
        ax.set(xlabel=r'$\tau_{\min}t$ (upper limit: 20)',ylabel=r'$E_0/t$' if row==0 else r'$Z_0$')
        if row==0: ax.set_title(rf'$\lambda={lam}$')
        ax.ticklabel_format(useOffset=False,axis='y')
        if column==0 and row==0: ax.legend(frameon=False,fontsize=8)
save(fig,'fit-windows')

fig,axes=plt.subplots(1,2,figsize=(9,3.8))
for ax,lam in zip(axes,[.25,.5]):
    record=mass[str(lam)];primary=record['primary'];points=record['points']
    k=np.array([r['k'] for r in points]);E=np.array([r['E'] for r in points]);err=np.array([r['error'] for r in points])
    x=np.linspace(0,.45,200)
    curve=primary['E_intercept']+primary['quadratic']*x*x+primary['quartic']*x**4
    ax.errorbar(k*k,E,err,fmt='o',ms=4,capsize=3,color=blue,label='Independent DiagMC chains')
    ax.plot(x*x,curve,color=gray,label=r'$b_0+c_2k^2+c_4k^4$')
    ax.set(xlabel=r'$k^2$ ($a=1$)',ylabel=r'$E(k)/t$',title=rf'$\lambda={lam}$')
    ax.text(.05,.85,rf'$m^*/m_0={primary["mass_ratio"]:.3f}\pm{primary["mass_ratio_error"]:.3f}$',transform=ax.transAxes)
    ax.legend(frameon=False,fontsize=8,loc='lower right');ax.ticklabel_format(useOffset=False,axis='y')
save(fig,'dispersion')

fig,axes=plt.subplots(2,2,figsize=(9,6.4))
for column,lam in enumerate([.25,.5]):
    stored=np.load(ROOT/'results/spectral_02'/f'lambda{lam:.2f}.npz');axis=stored['axis']
    for row,(value,ref,suffix) in enumerate([('A','reference',''),('rest','reference_rest','rest_')]):
        ax=axes[row,column]
        ax.fill_between(axis,stored['sensitivity_'+suffix+'low'],stored['sensitivity_'+suffix+'high'],
                        color='0.87',label='Regularization / grid / covariance scan')
        ax.fill_between(axis,stored['noise_'+suffix+'low'],stored['noise_'+suffix+'high'],
                        color='#bad5e7',alpha=.8,label='Noise perturbations (16–84%)')
        ax.plot(axis,stored[value],color=blue,lw=1.5,label='Regularized DiagMC')
        ax.plot(axis,stored[ref],color='0.15',ls='--',lw=1.2,label='VED / Lanczos reference')
        ax.set(xlabel=r'$\omega/t$',ylabel=r'$A_\eta(0,\omega)t$' if row==0 else r'$A_{{\rm rest},\eta}(0,\omega)t$',
               xlim=(-3.1,4.5),ylim=(0,None))
        if row==0: ax.set_title(rf'$\lambda={lam},\quad\eta/t=0.25$')
        if row==1 and column==0: ax.legend(frameon=False,fontsize=7,loc='upper right')
save(fig,'spectra')

fig,axes=plt.subplots(1,2,figsize=(9,3.8))
for ax,lam in zip(axes,[.25,.5]):
    record=spectral[str(lam)];alphas=np.array(record['alphas'])
    mean=np.array(record['cv_mean']);se=np.array(record['cv_se'])
    ax.plot(alphas,mean,color=blue)
    ax.fill_between(alphas,mean-se,mean+se,color='#bad5e7',alpha=.6)
    ax.axvline(record['selected_alpha'],color=gray,ls='--',label='Selected alpha')
    ax.set(xscale='log',xlabel=r'Regularization $\alpha$',ylabel='Held-out score per mode',
           title=rf'$\lambda={lam}$',ylim=(0,4))
    ax.legend(frameon=False,fontsize=8)
save(fig,'spectral-validation')

lines=['# Bare DiagMC 数值结果','',
'计算日期：2026-09-18。1D、零温、单电子、无限晶格；\\(t=\\omega_0=\\hbar=a=1\\)，',
'\\(\\lambda=g^2/(2t\\omega_0)\\)。括号和 ± 仅表示一个统计标准误差，系统检查另列。','',
'## 基态与有效质量','',
'| λ | E₀/t | Z₀ | m*/m₀ | m*（m₀=0.5） |','|---|---:|---:|---:|---:|']
table=[]
for lam in [.25,.5]:
    data=base[f'lambda{lam:.2f}_k0.00_base'];p=data['primary'];m=mass[str(lam)]['primary']
    row=dict(lambda_=lam,E=p['E'],E_error=p['E_error'],Z=p['Z'],Z_error=p['Z_error'],
             mass_ratio=m['mass_ratio'],mass_ratio_error=m['mass_ratio_error'])
    table.append(row)
    lines.append(f'| {lam} | {p["E"]:.7f} ± {p["E_error"]:.7f} | {p["Z"]:.5f} ± {p["Z_error"]:.5f} | {m["mass_ratio"]:.4f} ± {m["mass_ratio_error"]:.4f} | {m["mass"]:.4f} ± {m["mass_error"]:.4f} |')
lines += ['',
'每个耦合、每个动量使用 4 条链，每条 48,000,000 个生产步，另有 500,000 个热化步。',
'基态主拟合区间为 τ∈[6,20]，外部虚时范围 T=24，箱宽 0.25。',
'动量为 k=0,0.10,0.15,0.20,0.30,0.45（弧度）；质量拟合包含 k⁴ 项。',
'λ=0.25 的六点质量拟合 χ²/dof=2.22，λ=0.5 为 0.42；上述误差未按 χ² 人为缩放。','',
'![虚时传播子与直接能量估计量](results/report/green.svg)','',
'![长时间拟合窗口检查](results/report/fit-windows.svg)','',
'![小动量色散](results/report/dispersion.svg)','',
'## 独立参考与控制计算','',
'| λ | VED E₀/t | VED Z₀ | 小窗口 k≤0.30 的 m*/m₀ |','|---|---:|---:|---:|']
for lam in [.25,.5]:
    r=next(r for r in refs if r['coupling']==lam and r['generations']==16);m=mass[str(lam)]['small_window']
    lines.append(f'| {lam} | {r["E"]:.12f} | {r["Z"]:.10f} | {m["mass_ratio"]:.4f} ± {m["mass_ratio_error"]:.4f} |')
lines += ['',
'VED 是独立对照，未用于替换 Monte Carlo 结果。基态参考比较了 12、14、16 代变分空间。',
'另运行了 μ 下移 0.15、T 增至 32、阶数上限由 96 改为 48 的控制链。',
'主计算最高访问阶数为 20 和 32；主计算及控制计算均未尝试越过阶数上限。',
'移动长时间窗口与缩小动量窗口所得结果相容；这不构成对所有残余偏差的严格上界。','',
'| λ | 控制项 | E₀/t | Z₀ |','|---|---|---:|---:|']
for name,data in controls.items():
    p=data['primary'];lam=data['parameters']['g']**2/2
    lines.append(f'| {lam:.2f} | {name.rsplit("_",1)[-1]} | {p["E"]:.6f} ± {p["E_error"]:.6f} | {p["Z"]:.5f} ± {p["Z_error"]:.5f} |')
lines += ['',
'C++ 运动学、详细平衡、虚时伸缩雅可比、条件积分测试通过；4 个 Python 分析测试通过。',
'自由电子、原子极限完整传播子和一阶展开的随机检验均通过；原子极限实际访问了交叉图。','',
'## 谱函数：初步重建，尚未通过精细谱形检验','',
'独立短虚时运行采用 μ=-2.8、T=12、箱宽 0.125，另外使用条件积分测量。',
'频率正则化由四条独立链留出验证选择；VED 谱只在选择完成后用于评估。',
'谱图使用 η=0.25t 的 Lorentz 展宽，比较窗口为 ω/t∈[−3.25,7]。',
'相对 L¹ 误差定义为该窗口内 |A−A_ref| 的积分除以 A_ref 的积分。','',
'| λ | 全谱相对 L¹ 误差 | 去掉基态极点后的相对 L¹ 误差 |','|---|---:|---:|']
for lam in [.25,.5]:
    s=spectral[str(lam)]
    lines.append(f'| {lam} | {s["spectral_l1_vs_reference"]:.2%} | {s["rest_l1_vs_reference"]:.2%} |')
lines += ['',
'**因此不能把当前非相干峰的位置、宽度或多峰结构当成已收敛的物理结论。**',
'基态能量和 Z 的正式结果仍来自上面的长虚时拟合，谱重建内部调整后的极点不取代它们。',
'λ=0.25 的谱拟合将极点能量移动了约 −2.71 个先验标准差，进一步提示了正则化偏差。',
'谱矩约束在线性化极点位移下实现；恢复非线性极点后最大矩残差约 1.3×10⁻⁵，已保存在 JSON 中。','',
'![谱函数及非相干部分](results/report/spectra.svg)','',
'灰带表示正则化、网格、截止和协方差阈值扫描，蓝带是 24 次相关高斯扰动的 16–84% 范围。',
'这些敏感性带不是完整置信区间，也不能覆盖未纳入的谱参数化偏差。',
'VED 谱本身已比较 14、16、18 代，以及 500/1000 次 Lanczos；在相同展宽下，',
'16→18 代的全谱差异低于 0.004%，远小于解析延拓偏差。','',
'![独立链交叉验证](results/report/spectral-validation.svg)','',
'## 数据与复现','',
'- [k=0 汇总](results/k0_01/summary.json)、[质量拟合](results/mass/summary.json)、[谱函数诊断](results/spectral_02/summary.json)。',
'- `results/*/manifest.json` 保存任务参数、源文件及可执行文件哈希、Slurm 作业号；各链的 `blocks.csv` 是原始块统计。',
'- `results/validation_01` 与 `validation_02`：原始直方图与条件积分的解析极限检验。',
'- `results/spectral_01` 保留最初重建及失败诊断；当前图使用 `spectral_02`，没有覆盖旧结果。',
'- 每张图同时提供 SVG、PDF 和 PNG，位于 `results/report/`。',
'- 算法与命令见 [README.md](README.md)。','']
(ROOT/'RESULTS.md').write_text('\n'.join(lines))
summary=dict(date='2026-09-18',model=dict(t=1,omega0=1,dimension=1,temperature=0,electrons=1),
             results=table,mass=mass,spectral=spectral)
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
np.savetxt(out/'observables.csv',np.array([list(row.values()) for row in table]),delimiter=',',
           header='lambda,E0,E0_statistical_se,Z,Z_statistical_se,mass_ratio,mass_ratio_statistical_se',comments='')
print('Wrote RESULTS.md and five standalone SVG/PDF/PNG figures.')
