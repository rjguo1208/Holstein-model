"""Check the spectral reference itself in basis size and Lanczos length."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
PROJECT=ROOT.parent/'NNQS/holstein_lrvmc'
sys.path.insert(0,str(PROJECT))
from holstein_lrvmc.model import Holstein,VEDBasis
from holstein_lrvmc.spectral import lanczos_spectrum,ground_state

out=ROOT/'results/reference_spectral_01'
out.mkdir(exist_ok=False)
records=[]
for nh in [14,16,18]:
    basis=VEDBasis(nh)
    for coupling in [.25,.5]:
        H=basis.hamiltonian(0.,Holstein(1.,coupling))
        E,Z,residual,_=ground_state(H)
        for steps in [500,1000]:
            spectrum,_,_=lanczos_spectrum(H,steps=steps,reorthogonalize=False)
            spectrum.save(out/f'lambda{coupling:.2f}_nh{nh}_steps{steps}.npz')
            r=dict(coupling=coupling,generations=nh,dimension=basis.dim,steps=steps,E=E,Z=Z,
                   residual=residual,moments=[spectrum.moment(j) for j in range(3)])
            records.append(r)
            print(r,flush=True)
            (out/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
    del basis,H
sources=[PROJECT/'holstein_lrvmc'/s for s in ['model.py','spectral.py']]+[Path(__file__)]
(out/'provenance.json').write_text(json.dumps({str(p):sha256(p.read_bytes()).hexdigest() for p in sources},indent=2)+'\n')
