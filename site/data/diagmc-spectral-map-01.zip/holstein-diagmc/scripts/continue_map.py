"""Continue every measured momentum, then render an explicitly preliminary map."""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import sys
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from analysis import estimate_green
from map_continuation import rebin_conditional, select, lorentz_map
from plot_spectral_map import draw


def public(x):
    if isinstance(x, np.ndarray): return x.tolist()
    if isinstance(x, np.generic): return x.item()
    if isinstance(x, dict): return {k: public(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [public(v) for v in x]
    return x


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', required=True, type=Path)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--points', type=int, default=17)
    parser.add_argument('--couplings', nargs='+', type=float, default=[.25, .5])
    parser.add_argument('--bootstrap', type=int, default=8)
    parser.add_argument('--size', type=int, default=281)
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    sources = [ROOT/p for p in ['analysis.py', 'continuation.py', 'spectral_cv.py',
        'map_continuation.py', 'scripts/continue_map.py', 'scripts/plot_spectral_map.py']]
    manifest = dict(arguments=vars(args), method='bare DiagMC G + positive full-grid continuation',
        job_id=os.environ.get('SLURM_JOB_ID'), complete=False, inputs={}, sources={})
    manifest['arguments'] = {k: str(v) if isinstance(v, Path) else v
                             for k, v in vars(args).items()}
    for p in sources:
        dest = args.out/'source'/p.relative_to(ROOT)
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(p, dest)
        manifest['sources'][str(p.relative_to(ROOT))] = sha256(p.read_bytes()).hexdigest()
    def provenance():
        (args.out/'provenance.json').write_text(json.dumps(manifest, indent=2)+'\n')
    provenance()
    axis = np.linspace(-3.25, 5.5, 701)
    etas = np.array([.25, .5, 1.])
    alphas = np.r_[0., np.logspace(-9, 3, 13)]
    summary = {}
    output_files = []
    for coupling in args.couplings:
        entries = []
        for p in args.data.glob(f'ik*/conditional/lambda{coupling:.2f}_ik*/summary.json'):
            meta = json.loads(p.read_text())
            entries.append((meta['parameters']['k'], p.parent, meta))
        entries.sort()
        expected = np.linspace(0, np.pi, args.points)
        if len(entries) != args.points or not np.allclose([e[0] for e in entries], expected,
                                                        rtol=0, atol=1e-12):
            raise ValueError(f'Incomplete or duplicate k path for lambda={coupling}')
        maps, low, high, records = [], [], [], []
        for ik, (k, path, meta) in enumerate(entries):
            p = meta['parameters']
            saved = np.load(path/'green.npz', allow_pickle=False)
            tau, blocks, p = rebin_conditional(saved['blocks'], p)
            owners = saved['owners']
            manifest['inputs'][str(path/'green.npz')] = sha256((path/'green.npz').read_bytes()).hexdigest()
            fit, cv = select(tau, blocks, owners, p, alphas, size=args.size)
            curves = np.array([lorentz_map(axis, fit['energies'], fit['weights'], eta)
                               for eta in etas])
            rng = np.random.default_rng(97481+ik*100+int(coupling*100))
            boot = []
            for _ in range(args.bootstrap):
                sample = np.concatenate([
                    group[rng.integers(len(group), size=len(group))]
                    for group in [blocks[owners == owner] for owner in np.unique(owners)]])
                bf, _ = select(tau, sample, owners, p, alphas, size=args.size)
                boot.append([lorentz_map(axis, bf['energies'], bf['weights'], eta)
                             for eta in etas])
            maps.append(curves)
            if boot:
                lo, hi = np.quantile(boot, [.16, .84], axis=0)
            else:
                lo = hi = np.full_like(curves, np.nan)
            low.append(lo); high.append(hi)
            residual = np.max(abs(fit['moment_residuals']))
            record = dict(k=k, fit=fit, cv=cv, cap_attempts=meta['cap_attempts'],
                input=meta, checks=dict(moment_residual_below_1e_minus_5=bool(residual < 1e-5),
                    no_order_cap_attempts=meta['cap_attempts'] == 0,
                    alpha_inside_scan=not cv['boundary']),
                spectral_resolution_validated=False)
            records.append(record)
            np.savez_compressed(args.out/f'lambda{coupling:.2f}_ik{ik:03d}.npz',
                tau=tau, **dict(zip(['G', 'covariance'],
                              estimate_green(blocks, p)[:2])),
                energies=fit['energies'], weights=fit['weights'],
                predicted=fit['predicted'], eta=etas, energy=axis, A=curves,
                bootstrap_16=lo, bootstrap_84=hi)
            print(f'lambda={coupling}, k/pi={k/np.pi:.4f}, alpha={fit["alpha"]}, '
                  f'CV={np.mean(cv["folds"], axis=0)[cv["selected"]]:.3g}', flush=True)
        file = args.out/f'lambda{coupling:.2f}_map.npz'
        np.savez_compressed(file, k=expected, energy=axis, eta=etas,
            A=np.stack(maps, axis=1), bootstrap_16=np.stack(low, axis=1),
            bootstrap_84=np.stack(high, axis=1), coupling=coupling, t=1., omega0=1.,
            method='preliminary bare DiagMC continuation; resolution not validated')
        output_files.append(file)
        summary[str(coupling)] = records
        (args.out/'summary.json').write_text(json.dumps(public(summary), indent=2)+'\n')
    for eta in [.25, 1.]:
        draw(output_files, args.out/f'eta{eta:g}', eta,
             method='Bare DiagMC continuation (preliminary)')
    manifest['complete'] = True
    manifest['spectral_resolution_validated'] = False
    provenance()


if __name__ == '__main__':
    main()
