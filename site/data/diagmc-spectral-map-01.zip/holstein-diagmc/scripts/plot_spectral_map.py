"""Render sampled spectral columns with common absolute units and no k smoothing."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import re
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm, Normalize
import numpy as np


def draw(files, output, eta=.25, method='VED/Lanczos reference'):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    data = []
    for file in files:
        with np.load(file, allow_pickle=False) as d:
            i = int(np.argmin(abs(d['eta']-eta)))
            if abs(d['eta'][i]-eta) > 1e-10:
                raise ValueError(f'eta={eta} missing from {file}')
            A = d['A'][i]
            if A.shape != (len(d['k']), len(d['energy'])) or np.any(A < 0):
                raise ValueError('Invalid spectral map dimensions or positivity')
            data.append(dict(k=d['k'], energy=d['energy'], A=A,
                             coupling=float(d['coupling'])))
    vmax = np.ceil(max(d['A'].max() for d in data)*10)/10
    plt.rcParams.update({'font.size': 11, 'axes.titlesize': 12,
                         'mathtext.fontset': 'stix', 'svg.fonttype': 'path',
                         'savefig.facecolor': 'white'})
    for scale in ['linear', 'log']:
        fig, axes = plt.subplots(1, len(data), figsize=(10.2, 5.4), sharey=True,
                                 layout='constrained', squeeze=False)
        norm = Normalize(0, vmax) if scale == 'linear' else LogNorm(1e-3, vmax)
        for ax, d in zip(axes[0], data):
            mesh = ax.pcolormesh(d['k']/np.pi, d['energy'], d['A'].T,
                shading='nearest', cmap='magma', norm=norm, rasterized=False,
                linewidth=0, antialiased=False)
            ax.set(xlim=(0, 1), ylim=(d['energy'][0], d['energy'][-1]),
                   xlabel=r'$k$ path ($a=1$)',
                   title=rf'$\lambda={d["coupling"]:g}$')
            ax.set_xticks([0, .25, .5, .75, 1],
                [r'$\Gamma\;(0)$', r'$\pi/4$', r'$\pi/2$', r'$3\pi/4$', r'$X\;(\pi)$'])
        axes[0, 0].set_ylabel(r'Energy $\omega/t$ (vacuum = 0)')
        cb = fig.colorbar(mesh, ax=list(axes[0]), pad=.025, fraction=.035)
        cb.solids.set_rasterized(False)
        cb.set_label(r'$t\,A_\eta(k,\omega)$'+'  ('+scale+' scale)')
        fig.suptitle(method+'\n'+rf'$t=\omega_0=1,\quad \eta={eta:g}t$', fontsize=13)
        stem = output/f'spectral-map-{scale}'
        fig.savefig(stem.with_suffix('.svg'))
        # Adjacent vector cells otherwise show antialias seams in browsers.
        # Apply crisp cell edges only to the mesh groups, preserving smooth
        # mathematical labels, exact cell coordinates and all numerical data.
        svg = stem.with_suffix('.svg')
        svg.write_text(re.sub(r'(<g id="QuadMesh_[^"]+")>',
            r'\1 shape-rendering="crispEdges">', svg.read_text()))
        # PDF has no crispEdges hint; same-color edge overlap prevents its
        # viewer from exposing white hairlines between adjacent opaque cells.
        cells = [ax.collections[0] for ax in axes[0]]+[cb.solids]
        for cell in cells:
            cell.set_edgecolor('face')
            cell.set_linewidth(.25)
        fig.savefig(stem.with_suffix('.pdf'))
        for cell in cells:
            cell.set_edgecolor('none')
            cell.set_linewidth(0)
        fig.savefig(stem.with_suffix('.png'), dpi=180)
        plt.close(fig)
    (output/'plot.json').write_text(json.dumps(dict(eta=eta, method=method,
        color='absolute t*A; one common scale across couplings',
        color_max=float(vmax), log_color_min=1e-3,
        k_interpolation='none; nearest-cell rendering of independently calculated k values',
        files=[str(p) for p in files]), indent=2)+'\n')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('files', nargs='+', type=Path)
    parser.add_argument('--out', required=True)
    parser.add_argument('--eta', type=float, default=.25)
    parser.add_argument('--method', default='VED/Lanczos reference')
    args = parser.parse_args()
    draw(args.files, args.out, args.eta, args.method)
