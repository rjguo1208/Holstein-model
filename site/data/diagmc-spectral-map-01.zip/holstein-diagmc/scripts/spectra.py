"""Initial k=0 spectra; record regularization/grid/noise dependence explicitly."""
from hashlib import sha256
import json
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from continuation import reconstruct,broaden,perturb_ez

out=ROOT/'results/spectral_01'
if out.exists(): raise SystemExit('Refusing to overwrite spectral output')
out.mkdir()
summary={}
for coupling in [.25,.5]:
    source=ROOT/'results/k0_01/analysis'/f'lambda{coupling:.2f}_k0.00_base'
    meta=json.loads((source/'summary.json').read_text());p=meta['parameters'];primary=meta['primary']
    saved=np.load(source/'green.npz');tau,G,C=(saved[k] for k in ['tau','G','covariance'])
    E,Z=primary['E'],primary['Z']
    result=reconstruct(tau,G,C,p,E,Z)
    chosen=result['fits'][result['selected']]
    axis=np.linspace(-3.25,7,1601);eta=.25
    spectrum,rest=broaden(axis,result['omega'],chosen['weights'],E,Z,eta)
    scans=[];sensitivity=[]
    for fit in result['fits']:
        scans.append({k:v for k,v in fit.items() if k!='weights'})
        if fit['chi2_per_bin']<=1.2:
            sensitivity.append(broaden(axis,result['omega'],fit['weights'],E,Z,eta)[0])
    grid=[]
    for cutoff,size in [(8.,120),(16.,240),(12.,240)]:
        trial=reconstruct(tau,G,C,p,E,Z,cutoff,size)
        f=trial['fits'][trial['selected']]
        curve=broaden(axis,trial['omega'],f['weights'],E,Z,eta)[0]
        sensitivity.append(curve)
        grid.append(dict(cutoff=cutoff,size=size,alpha=f['alpha'],chi2_per_bin=f['chi2_per_bin'],
            l1_change=float(np.trapezoid(np.abs(curve-spectrum),axis)/np.trapezoid(spectrum,axis))))
    rng=np.random.default_rng(2791+round(coupling*100))
    v,U=np.linalg.eigh(C)
    root=U*np.sqrt(np.maximum(v,0))
    noise=[]
    for _ in range(24):
        delta=root@rng.normal(size=len(tau))
        e,z=perturb_ez(delta,G,C,tau,p['tau_max']/p['bins'],p['mu'],E,Z)
        if not 0<z<1: raise ValueError('Unphysical perturbed residue')
        trial=reconstruct(tau,G+delta,C,p,e,z,alphas=[chosen['alpha']])
        noise.append(broaden(axis,trial['omega'],trial['fits'][0]['weights'],e,z,eta)[0])
    sensitivity=np.asarray(sensitivity if sensitivity else [spectrum])
    low,high=np.quantile(noise,[.16,.84],axis=0)
    poles=np.load(ROOT/'results/reference_01'/f'poles_lambda{coupling:.2f}.npz')
    reference=(eta/np.pi/((axis[:,None]-poles['energies'][None,:])**2+eta**2))@poles['weights']
    refdata=json.loads((ROOT/'results/reference_01/reference.json').read_text())
    ref=next(r for r in refdata if r['coupling']==coupling and r['generations']==16)
    refrest=reference-ref['Z']*eta/np.pi/((axis-ref['E'])**2+eta**2)
    np.savez_compressed(out/f'lambda{coupling:.2f}.npz',axis=axis,A=spectrum,rest=rest,reference=reference,
        reference_rest=refrest,noise_low=low,noise_high=high,sensitivity_low=sensitivity.min(axis=0),
        sensitivity_high=sensitivity.max(axis=0),energies=result['omega'],weights=chosen['weights'])
    summary[str(coupling)]=dict(eta=eta,E=E,Z=Z,alpha=chosen['alpha'],
        chi2_per_bin=chosen['chi2_per_bin'],discrepancy_met=result['discrepancy_met'],
        moment_residuals=chosen['moment_residuals'],regularization_scan=scans,grid_scan=grid,
        noise_replicates=len(noise),
        spectral_l1_vs_reference=float(np.trapezoid(abs(spectrum-reference),axis)/np.trapezoid(reference,axis)),
        rest_l1_vs_reference=float(np.trapezoid(abs(rest-refrest),axis)/np.trapezoid(refrest,axis)),
        status='regularized preliminary reconstruction; no high-resolution spectral claim',
        input_sha256=sha256((source/'green.npz').read_bytes()).hexdigest())
    (out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    print(coupling,{k:v for k,v in summary[str(coupling)].items() if k not in ['regularization_scan','grid_scan']},flush=True)
(out/'source_hashes.json').write_text(json.dumps({name:sha256((ROOT/name).read_bytes()).hexdigest() for name in ['continuation.py','scripts/spectra.py']},indent=2)+'\n')
