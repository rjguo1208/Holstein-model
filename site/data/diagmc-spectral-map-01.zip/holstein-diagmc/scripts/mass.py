"""Extract the effective mass from independently sampled small-k energies."""
from pathlib import Path
import json
import numpy as np

ROOT=Path(__file__).resolve().parents[1]
results=json.loads((ROOT/'results/k0_01/summary.json').read_text())
for name in ['dispersion_01','dispersion_smallk_01']:
    path=ROOT/'results'/name/'summary.json'
    if path.exists(): results.update(json.loads(path.read_text()))
refs=json.loads((ROOT/'results/reference_k_01/reference.json').read_text())
extra=ROOT/'results/reference_smallk_01/reference.json'
if extra.exists(): refs+=json.loads(extra.read_text())
output={}
for coupling in [.25,.5]:
    points=sorted([r for name,r in results.items() if name.startswith(f'lambda{coupling:.2f}_')],key=lambda r:r['parameters']['k'])
    k=np.array([r['parameters']['k'] for r in points])
    E=np.array([r['primary']['E'] for r in points]); err=np.array([r['primary']['E_error'] for r in points])
    def fit(selection,quartic):
        x=k[selection]; y=E[selection]; sigma=err[selection]
        X=np.column_stack([x**(2*j) for j in range(3 if quartic else 2)])
        covariance=np.linalg.inv((X.T/sigma**2)@X)
        beta=covariance@((X.T/sigma**2)@y)
        return dict(E_intercept=float(beta[0]),quadratic=float(beta[1]),
                    quartic=float(beta[2]) if quartic else None,
                    mass_ratio=float(1/beta[1]),mass_ratio_error=float(np.sqrt(covariance[1,1])/beta[1]**2),
                    mass=float(.5/beta[1]),mass_error=float(.5*np.sqrt(covariance[1,1])/beta[1]**2),
                    chi2_per_dof=float(np.sum(((y-X@beta)/sigma)**2)/(len(x)-len(beta))) if len(x)>len(beta) else None,
                    k_max=float(x[-1]))
    reference=sorted([r for r in refs if r['coupling']==coupling and r['generations']==14],key=lambda r:r['k'])
    xr=np.array([r['k'] for r in reference]);yr=np.array([r['E'] for r in reference])
    br=np.linalg.lstsq(np.column_stack([np.ones(len(xr)),xr*xr,xr**4]),yr,rcond=None)[0]
    output[str(coupling)]=dict(points=[dict(k=float(x),E=float(y),error=float(s)) for x,y,s in zip(k,E,err)],
        primary=fit(np.ones(len(k),bool),True),small_window=fit(k<=.3,True),
        quadratic_only=fit(k<=.3,False),
        reference_mass_ratio_same_k_fit=float(1/br[1]))
out=ROOT/'results/mass';out.mkdir(exist_ok=True)
(out/'summary.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
