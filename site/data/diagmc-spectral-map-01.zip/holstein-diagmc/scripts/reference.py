"""Independent infinite-lattice VED benchmarks; never used in DiagMC sampling."""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
from pathlib import Path
import sys
import numpy as np

parser=argparse.ArgumentParser()
parser.add_argument('--project',default='/home/x-rg47749/code/NNQS/holstein_lrvmc')
parser.add_argument('--out',required=True)
parser.add_argument('--momenta',type=float,nargs='+',default=[0])
parser.add_argument('--generations',type=int,nargs='+',default=[12,14,16])
parser.add_argument('--no-spectra',action='store_true')
parser.add_argument('--couplings',type=float,nargs='+',default=[.25,.5])
parser.add_argument('--omega',type=float,default=1.)
args=parser.parse_args()
sys.path.insert(0,args.project)
from holstein_lrvmc.model import Holstein,VEDBasis
from holstein_lrvmc.spectral import ground_state,lanczos_spectrum
out=Path(args.out)
if out.exists(): raise SystemExit('Refusing to overwrite reference results')
out.mkdir(parents=True)
records=[]
for nh in args.generations:
    basis=VEDBasis(nh)
    for coupling in args.couplings:
        model=Holstein(args.omega,coupling)
        for k in args.momenta:
            H=basis.hamiltonian(k,model)
            E,Z,residual,_=ground_state(H)
            records.append(dict(generations=nh,dimension=basis.dim,coupling=coupling,omega=args.omega,k=k,E=E,Z=Z,residual=residual))
            print(records[-1],flush=True)
            (out/'reference.json').write_text(json.dumps(records,indent=2)+'\n')
            if nh==max(args.generations) and k==0 and not args.no_spectra:
                spectrum,alpha,beta=lanczos_spectrum(H,steps=500,reorthogonalize=False)
                spectrum.save(out/f'poles_lambda{coupling:.2f}.npz')
sources=[Path(args.project)/'holstein_lrvmc'/name for name in ['model.py','spectral.py']]
(out/'provenance.json').write_text(json.dumps({str(p):sha256(p.read_bytes()).hexdigest() for p in sources},indent=2)+'\n')
