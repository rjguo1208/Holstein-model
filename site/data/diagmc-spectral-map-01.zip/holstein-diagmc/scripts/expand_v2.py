"""Execute the authorized coupling expansion only after the quality gate passes."""
import json
import os
from pathlib import Path
import subprocess
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from analysis import read_runs
from direct_mass import fit_direct_mass

quality=json.loads((ROOT/'results/quality_02.json').read_text())
status_path=ROOT/'results/extension_02_status.json'
if status_path.exists():raise SystemExit('Refusing to overwrite expansion status')
if not quality['extension_gate_passed']:
    status_path.write_text(json.dumps(dict(status='not started',reason=quality['status'],
        quality='results/quality_02.json'),indent=2)+'\n')
    print('Coupling expansion held: the predefined quality gate did not pass.')
    raise SystemExit(0)
jobs=min(4,int(os.environ.get('SLURM_CPUS_PER_TASK','1')))
subprocess.run([sys.executable,str(ROOT/'scripts/run_suite.py'),'k0','--out',str(ROOT/'results/coupling_02'),
                '--couplings','.75','1.','1.5','--jobs',str(jobs),'--seed-offset','237000000'],check=True,cwd=ROOT)
subprocess.run([sys.executable,str(ROOT/'scripts/reference.py'),'--out',str(ROOT/'results/reference_coupling_02'),
                '--couplings','.75','1.','1.5','--generations','16','18','--no-spectra'],check=True,cwd=ROOT)
records={}
for lam in [.75,1.,1.5]:
    paths=sorted(p for p in (ROOT/'results/coupling_02').glob(f'lambda{lam:.2f}_k0.00_base_s*') if p.is_dir())
    rows,owners,metas=read_runs(paths)
    records[str(lam)]=dict(primary=fit_direct_mass(rows,owners,metas[0],8,20,time_bin_factor=4),
        windows=[fit_direct_mass(rows,owners,metas[0],lower,20,time_bin_factor=4) for lower in [6,8,10]])
(ROOT/'results/coupling_02/direct_mass.json').write_text(json.dumps(records,indent=2)+'\n')
status_path.write_text(json.dumps(dict(status='sampling and reference complete; inspect convergence before interpreting',
    couplings=[.75,1.,1.5],omega=1.,results='results/coupling_02',reference='results/reference_coupling_02'),indent=2)+'\n')
