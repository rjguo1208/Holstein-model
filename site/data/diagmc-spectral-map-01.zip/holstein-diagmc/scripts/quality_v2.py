"""Report predefined assessment targets; never turn a failed target into success."""
import argparse
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--mass',default='results/mass_direct_02')
parser.add_argument('--spectra',default='results/spectral_04')
parser.add_argument('--out',required=True)
args=parser.parse_args()
mass=json.loads((ROOT/args.mass/'summary.json').read_text())
spectra=json.loads((ROOT/args.spectra/'summary.json').read_text())
checks={}
for key,m in mass.items():
    p=m['primary'];ref=m['reference_curvature'][-1]['mass_ratio']
    window_spread=m['window_span'][1]-m['window_span'][0]
    s=spectra[key]
    tikh_score=min(s['tikhonov_cv']['mean'])
    som_cv=s['som_cv']['cv'];som_score=min(sum(col)/len(col) for col in zip(*som_cv))
    # The method is chosen by held-out prediction, not by reference error.
    selected='tikhonov' if tikh_score<=som_score else 'som'
    rest_error=s[selected+'_errors']['rest']
    mass_checks=dict(relative_statistical_error=p['mass_ratio_error']/p['mass_ratio'],
        relative_window_span=window_spread/p['mass_ratio'],
        reference_difference_in_statistical_sigma=abs(p['mass_ratio']-ref)/p['mass_ratio_error'])
    mass_pass=(mass_checks['relative_statistical_error']<.01 and
               mass_checks['relative_window_span']<.01 and
               abs(p['mass_ratio']-ref)<3*p['mass_ratio_error']+window_spread)
    checks[key]=dict(mass=mass_checks,mass_target_met=mass_pass,
        selected_spectral_method=selected,rest_relative_l1_at_eta025=rest_error,
        spectral_target_met=rest_error<.10,
        moment_constraints_met=max(abs(x) for x in s['tikhonov']['moment_residuals'])<1e-5)
complete=all(v['mass_target_met'] and v['spectral_target_met'] and v['moment_constraints_met'] for v in checks.values())
record=dict(checks=checks,extension_gate_passed=complete,
    next_parameter_scan='lambda=0.75,1.0,1.5 at omega/t=1' if complete else None,
    status='ready for a separately documented coupling scan' if complete else
           'keep larger-coupling expansion pending; report achieved resolution and unresolved targets')
target=ROOT/args.out
if target.exists():raise SystemExit('Refusing to overwrite a quality assessment')
target.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
