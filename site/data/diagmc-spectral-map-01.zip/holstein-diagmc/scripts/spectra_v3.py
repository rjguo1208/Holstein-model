"""Exact-pole Tikhonov/SOM comparison, block-bootstrap CV, and noise benchmarks.

Actual-data model selection completes before any reference spectrum is loaded.
Synthetic reference spectra are separate validation cases, not tuning inputs.
"""
from __future__ import annotations
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import sys
import time
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from analysis import estimate_green
from continuation import bin_kernel
from spectral_cv import prior_covariance,whitening
from spectral_nonlinear import (SpectralProblem,tikhonov_scan,stochastic_rectangles,
                               broaden_fit,broaden_ensemble)


def public(value):
    if isinstance(value,np.ndarray):return value.tolist()
    if isinstance(value,(np.floating,np.integer)):return value.item()
    if isinstance(value,dict):return {k:public(v) for k,v in value.items()}
    if isinstance(value,list):return [public(v) for v in value]
    return value


def score(prediction,case):
    W=whitening(case['G'],case['C'],1e-8)
    r=W@(prediction-case['G'])
    return float(r@r/len(W))


def cases_from_blocks(blocks,owners,p):
    full=estimate_green(blocks,p)[:2]
    folds=[]
    for owner in np.unique(owners):
        train=estimate_green(blocks[owners!=owner],p)[:2]
        test=estimate_green(blocks[owners==owner],p)[:2]
        folds.append((dict(G=train[0],C=train[1]),dict(G=test[0],C=test[1])))
    return dict(G=full[0],C=full[1]),folds


def choose_tikh(tau,p,prior,pcov,full,folds,alphas,size,jobs=1):
    def fold_score(pair):
        train,test=pair
        pb=SpectralProblem(tau,train['G'],train['C'],p,prior,pcov)
        fits=tikhonov_scan(pb,alphas,size=size)
        return [score(f['predicted'],test) for f in fits]
    with ThreadPoolExecutor(max_workers=jobs) as pool:
        cv=np.asarray(list(pool.map(fold_score,folds)))
    mean=cv.mean(axis=0);se=cv.std(axis=0,ddof=1)/np.sqrt(len(cv))
    selected=int(np.argmin(mean))
    pb=SpectralProblem(tau,full['G'],full['C'],p,prior,pcov)
    fits=tikhonov_scan(pb,alphas,size=size)
    return fits[selected],dict(alphas=alphas,cv=cv,mean=mean,se=se,selected=selected,
        selected_alpha=alphas[selected],rule='minimum mean held-out-chain score; uncertainty reselects alpha',
        boundary=selected in [0,len(alphas)-1]),fits


def choose_som(tau,p,prior,pcov,full,folds,steps,solutions,seed,jobs=1):
    tasks=[(i,j,train,test,n) for i,(train,test) in enumerate(folds) for j,n in enumerate(steps)]
    def fold_score(task):
        i,j,train,test,n=task
        pb=SpectralProblem(tau,train['G'],train['C'],p,prior,pcov)
        ensemble=stochastic_rectangles(pb,seed=seed+i*100+j,solutions=solutions,updates=n)
        return i,j,score(ensemble['predicted'],test)
    cv=np.zeros((len(folds),len(steps)))
    with ThreadPoolExecutor(max_workers=jobs) as pool:
        for i,j,value in pool.map(fold_score,tasks):cv[i,j]=value
    selected=int(np.argmin(cv.mean(axis=0)))
    pb=SpectralProblem(tau,full['G'],full['C'],p,prior,pcov)
    ensemble=stochastic_rectangles(pb,seed=seed+9999,solutions=4*solutions,updates=steps[selected])
    return ensemble,dict(updates=steps,cv=cv,selected=selected,selected_updates=steps[selected],
        rule='minimum mean held-out-chain score',solutions_per_fold=solutions)


def bootstrap_blocks(blocks,owners,rng):
    result=[]
    for owner in np.unique(owners):
        group=blocks[owners==owner]
        result.append(group[rng.integers(len(group),size=len(group))])
    return np.concatenate(result)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',required=True)
    parser.add_argument('--data',default='results/spectral_data_01')
    parser.add_argument('--prior-data',default='results/k0_01/analysis')
    parser.add_argument('--bootstrap',type=int,default=32)
    parser.add_argument('--synthetic',type=int,default=8)
    parser.add_argument('--jobs',type=int,default=4)
    parser.add_argument('--som-solutions',type=int,default=8)
    parser.add_argument('--som-updates',type=int,nargs='+',default=[80,250,800])
    parser.add_argument('--couplings',type=float,nargs='+',default=[.25,.5])
    parser.add_argument('--size',type=int,default=180)
    args=parser.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=False)
    sources=[ROOT/'spectral_nonlinear.py',ROOT/'spectral_cv.py',ROOT/'analysis.py',ROOT/'continuation.py',Path(__file__)]
    source_hashes={str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in sources}
    for p in sources:
        target=out/'source'/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
    (out/'provenance.json').write_text(json.dumps(dict(arguments=vars(args),job_id=os.environ.get('SLURM_JOB_ID'),
        inputs={},sources=source_hashes,complete=False),indent=2)+'\n')
    inputs={};summary={};axis=np.linspace(-3.25,7,1601);eta=.25
    alphas=np.logspace(-4,4,13)
    def save():
        (out/'summary.json').write_text(json.dumps(public(summary),indent=2)+'\n')
    for coupling in args.couplings:
        start=time.monotonic();label=f'lambda{coupling:.2f}_k0.00_base'
        base=ROOT/args.prior_data/label
        baseline=json.loads((base/'summary.json').read_text())
        prior=np.array([baseline['primary'][name] for name in ['E','Z']])
        pcov=prior_covariance(baseline,np.load(base/'green.npz'))
        source=ROOT/args.data/'conditional'/label
        p=json.loads((source/'summary.json').read_text())['parameters']
        saved=np.load(source/'green.npz');tau,blocks,owners=(saved[k] for k in ['tau','blocks','owners'])
        full,folds=cases_from_blocks(blocks,owners,p)
        inputs[str(source/'green.npz')]=sha256((source/'green.npz').read_bytes()).hexdigest()
        fit,cv,scan=choose_tikh(tau,p,prior,pcov,full,folds,alphas,args.size,args.jobs)
        print('Tikhonov selected',coupling,fit['alpha'],fit['chi2_per_mode'],fit['prior_shift_sigma'],flush=True)
        ensemble,som_cv=choose_som(tau,p,prior,pcov,full,folds,args.som_updates,
                                  args.som_solutions,73851+int(coupling*100),args.jobs)
        print('SOM selected',coupling,som_cv['selected_updates'],ensemble['retained'],flush=True)
        tikh_curves=np.array(broaden_fit(axis,fit,eta));som_curves=broaden_ensemble(axis,ensemble,eta)
        rng=np.random.default_rng(73219+int(coupling*100))
        boot=[];boot_alpha=[];boot_prior=[]
        for b in range(args.bootstrap):
            sample=bootstrap_blocks(blocks,owners,rng)
            boot_full,boot_folds=cases_from_blocks(sample,owners,p)
            bp=rng.multivariate_normal(prior,pcov)
            bf,bc,_=choose_tikh(tau,p,bp,pcov,boot_full,boot_folds,alphas,args.size,args.jobs)
            boot.append(broaden_fit(axis,bf,eta));boot_alpha.append(bc['selected_alpha']);boot_prior.append([bf['E'],bf['Z']])
        print('Bootstrap complete',coupling,len(boot),flush=True)
        # Variation of support, grid, and covariance treatment at selected alpha.
        sensitivity=[]
        for cutoff,size,tol in [(8.,120,1e-8),(16.,240,1e-8),(12.,240,1e-8),
                                (12.,args.size,1e-6),(12.,args.size,1e-10)]:
            pb=SpectralProblem(tau,full['G'],full['C'],p,prior,pcov,tol)
            sf=tikhonov_scan(pb,[fit['alpha']],cutoff=cutoff,size=size)[0]
            curves=np.array(broaden_fit(axis,sf,eta))
            sensitivity.append(dict(cutoff=cutoff,size=size,tolerance=tol,
                rank=sf['rank'],chi2_per_mode=sf['chi2_per_mode'],
                relative_rest_change=float(np.trapezoid(abs(curves[1]-tikh_curves[1]),axis)/np.trapezoid(tikh_curves[1],axis))))
        # Actual-data selection is now finished. Independent benchmark access.
        ref=np.load(ROOT/f'results/reference_spectral_01/lambda{coupling:.2f}_nh18_steps1000.npz')
        info=json.loads((ROOT/'results/reference_spectral_01/summary.json').read_text())
        info=next(r for r in info if r['coupling']==coupling and r['generations']==18 and r['steps']==1000)
        ref_full=(eta/np.pi/((axis[:,None]-ref['energies'][None,:])**2+eta**2))@ref['weights']
        ref_rest=ref_full-info['Z']*eta/np.pi/((axis-info['E'])**2+eta**2)
        def errors(curves):
            return dict(full=float(np.trapezoid(abs(curves[0]-ref_full),axis)/np.trapezoid(ref_full,axis)),
                        rest=float(np.trapezoid(abs(curves[1]-ref_rest),axis)/np.trapezoid(ref_rest,axis)))
        exact=bin_kernel(tau,p['tau_max']/p['bins'],ref['energies'],p['mu'])@ref['weights']
        refprior=np.array([info['E'],info['Z']])
        values,vectors=np.linalg.eigh(full['C']);root=vectors*np.sqrt(np.maximum(values,0))
        noise_cases=[]
        for draw in range(args.synthetic):
            # Same covariance as actual chain means, independent synthetic chains.
            count=len(folds)
            chain_G=exact+np.sqrt(count)*(rng.normal(size=(count,len(tau)))@root.T)
            synthetic_full=dict(G=chain_G.mean(axis=0),C=full['C'])
            synthetic_folds=[(dict(G=np.delete(chain_G,i,axis=0).mean(axis=0),C=full['C']*count/(count-1)),
                              dict(G=chain_G[i],C=full['C']*count)) for i in range(count)]
            bp=rng.multivariate_normal(refprior,pcov)
            bf,bc,_=choose_tikh(tau,p,bp,pcov,synthetic_full,synthetic_folds,alphas,args.size,args.jobs)
            noise_cases.append(dict(draw=draw,alpha=bc['selected_alpha'],errors=errors(broaden_fit(axis,bf,eta)),
                prior_shift_sigma=bf['prior_shift_sigma']))
        # Distinguish pure optimization/representation error from noise effects.
        synthetic_pb=SpectralProblem(tau,exact,full['C'],p,refprior,pcov)
        clean_fit=tikhonov_scan(synthetic_pb,[fit['alpha']],size=args.size)[0]
        clean_som=stochastic_rectangles(synthetic_pb,seed=82911,solutions=2*args.som_solutions,
                                        updates=som_cv['selected_updates'])
        quantile=np.quantile(np.asarray(boot),[.16,.84],axis=0) if boot else np.stack([tikh_curves,tikh_curves])
        # Resolution dependence is an assessment, not a parameter-choice input.
        resolution=[]
        for width in [.15,.25,.4,.6,1.]:
            rf=(width/np.pi/((axis[:,None]-ref['energies'][None,:])**2+width**2))@ref['weights']
            rr=rf-info['Z']*width/np.pi/((axis-info['E'])**2+width**2)
            tc=broaden_fit(axis,fit,width);sc=broaden_ensemble(axis,ensemble,width)
            resolution.append(dict(eta=width,tikh_rest=float(np.trapezoid(abs(tc[1]-rr),axis)/np.trapezoid(rr,axis)),
                                   som_rest=float(np.trapezoid(abs(sc[1]-rr),axis)/np.trapezoid(rr,axis))))
        record=dict(parameters=p,prior=prior,prior_covariance=pcov,eta=eta,
            tikhonov=fit,tikhonov_cv=cv,som=ensemble,som_cv=som_cv,
            tikhonov_errors=errors(tikh_curves),som_errors=errors(som_curves),
            bootstrap_count=len(boot),bootstrap_alphas=boot_alpha,bootstrap_EZ=boot_prior,
            bootstrap_method='within-chain block bootstrap; independent correlated E/Z draw; repeat CV in every replicate',
            sensitivity=sensitivity,synthetic_noise=noise_cases,
            clean_tikhonov_errors=errors(broaden_fit(axis,clean_fit,eta)),
            clean_som_errors=errors(broaden_ensemble(axis,clean_som,eta)),resolution=resolution,
            forward_chi2_per_mode=score(exact,full),seconds=time.monotonic()-start)
        summary[str(coupling)]=record;save()
        np.savez_compressed(out/f'lambda{coupling:.2f}.npz',axis=axis,tikh=tikh_curves,som=som_curves,
            reference=np.stack([ref_full,ref_rest]),bootstrap_low=quantile[0],bootstrap_high=quantile[1],
            tau=tau,G=full['G'],G_error=np.sqrt(np.diag(full['C'])),G_reference=exact,
            G_tikh=fit['predicted'],G_som=ensemble['predicted'])
        print('Complete',coupling,'Tikh',record['tikhonov_errors'],'SOM',record['som_errors'],
              'seconds',record['seconds'],flush=True)
    (out/'provenance.json').write_text(json.dumps(dict(arguments=vars(args),job_id=os.environ.get('SLURM_JOB_ID'),
        inputs=inputs,sources=source_hashes,complete=True),indent=2)+'\n')

if __name__=='__main__':main()
