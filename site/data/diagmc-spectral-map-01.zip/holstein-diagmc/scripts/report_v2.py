"""Figures and a reviewable report for the second DiagMC iteration."""
import argparse
import json
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mass',default='results/mass_direct_02')
    parser.add_argument('--spectra',default='results/spectral_04')
    parser.add_argument('--out',default='results/report_02')
    args=parser.parse_args();out=ROOT/args.out;out.mkdir(parents=True,exist_ok=True)
    mass=json.loads((ROOT/args.mass/'summary.json').read_text())
    spectrum=json.loads((ROOT/args.spectra/'summary.json').read_text())
    old=json.loads((ROOT/'results/spectral_02/summary.json').read_text())
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'svg.fonttype':'none','pdf.fonttype':42})
    def save(fig,name):
        fig.tight_layout()
        for suffix in ['svg','pdf','png']:fig.savefig(out/f'{name}.{suffix}',dpi=160,bbox_inches='tight')
        plt.close(fig)
    fig,axes=plt.subplots(2,2,figsize=(10,6.3))
    for j,lam in enumerate([.25,.5]):
        m=mass[str(lam)];data=np.load(ROOT/args.mass/f'lambda{lam:.2f}.npz')
        ref=m['reference_curvature'][-1]['mass_ratio'];inv=2/ref
        use=(data['tau']>=4)&(data['tau']<=22)
        ax=axes[0,j];ax.errorbar(data['tau'][use],data['curvature'][use]-inv*data['tau'][use],
            yerr=data['error'][use],fmt='.',ms=3,lw=.7,color='#1764a0',label='DiagMC')
        p=m['primary'];tt=np.linspace(8,20,100)
        # The fit uses merged bins, while the displayed points retain the
        # original width. Exponential weighting shifts <tau> by a constant;
        # translate the intercept between bin widths before overlaying them.
        parameters=m['ground']['parameters'];rate=m['ground']['primary']['E']-parameters['mu']
        dt=parameters['tau_max']/parameters['bins']
        def mean_time_shift(width):
            if abs(rate*width)<1e-5:return -rate*width**2/12
            return 1/rate-width/(2*np.tanh(rate*width/2))
        intercept=p['intercept']+p['inverse_mass']*(mean_time_shift(dt)-mean_time_shift(dt*p['time_bin_factor']))
        ax.plot(tt,intercept+(p['inverse_mass']-inv)*tt,color='#b85b13',label='slope + intercept fit')
        ax.set(xlabel=r'$\tau t$',ylabel=r'$\langle K-J^2\rangle-\tau/m^*_{\rm VED}$',title=rf'$\lambda={lam}$')
        ax.legend(frameon=False,fontsize=8)
        ax=axes[1,j];windows=m['windows']
        ax.errorbar([f['tau_min'] for f in windows],[f['mass_ratio'] for f in windows],
            yerr=[f['mass_ratio_error'] for f in windows],fmt='o',color='#1764a0',label='direct estimator')
        ax.axhline(ref,color='black',ls='--',label=r'VED $k\to0$')
        ax.set(xlabel=r'lower fit limit $\tau_{\min}t$',ylabel=r'$m^*/m_0$')
        ax.legend(frameon=False,fontsize=8)
    save(fig,'direct-mass')
    fig,axes=plt.subplots(2,2,figsize=(10,6.5))
    for j,lam in enumerate([.25,.5]):
        d=np.load(ROOT/args.spectra/f'lambda{lam:.2f}.npz')
        for row in [0,1]:
            ax=axes[row,j]
            ax.plot(d['axis'],d['reference'][row],'k--',lw=1.2,label='independent VED')
            ax.plot(d['axis'],d['tikh'][row],color='#1764a0',lw=1.2,label='exact-pole Tikhonov')
            ax.plot(d['axis'],d['som'][row],color='#b85b13',lw=1.2,label='rectangle SOM variant')
            ax.fill_between(d['axis'],d['bootstrap_low'][row],d['bootstrap_high'][row],color='#1764a0',alpha=.16)
            ax.set(xlim=(-3.1,5.),xlabel=r'$\omega/t$',ylabel=r'$A(0,\omega)t$' if row==0 else r'$A_{\rm rest}(0,\omega)t$')
            if row==0:ax.set_title(rf'$\lambda={lam},\quad\eta/t=0.25$');ax.legend(frameon=False,fontsize=8)
    save(fig,'spectra-v2')
    fig,axes=plt.subplots(1,2,figsize=(10,3.4))
    for ax,lam in zip(axes,[.25,.5]):
        d=np.load(ROOT/args.spectra/f'lambda{lam:.2f}.npz');error=d['G_error']
        ax.plot(d['tau'],(d['G']-d['G_reference'])/error,label='data - VED',color='black')
        ax.plot(d['tau'],(d['G']-d['G_tikh'])/error,label='data - Tikhonov',color='#1764a0')
        ax.plot(d['tau'],(d['G']-d['G_som'])/error,label='data - SOM',color='#b85b13')
        ax.axhline(0,color='gray',lw=.6);ax.axhspan(-2,2,color='gray',alpha=.1)
        ax.set(xlabel=r'$\tau t$',ylabel=r'pointwise residual / $\sigma_G$',title=rf'$\lambda={lam}$')
        ax.legend(frameon=False,fontsize=8)
    save(fig,'forward-check')
    fig,axes=plt.subplots(1,2,figsize=(10,3.4))
    for ax,lam in zip(axes,[.25,.5]):
        s=spectrum[str(lam)];r=s['resolution']
        ax.plot([v['eta'] for v in r],[100*v['tikh_rest'] for v in r],'o-',color='#1764a0',label='Tikhonov')
        ax.plot([v['eta'] for v in r],[100*v['som_rest'] for v in r],'s-',color='#b85b13',label='SOM variant')
        ax.axhline(10,color='gray',ls='--',label='10% assessment target')
        ax.set(xlabel=r'Lorentz broadening $\eta/t$',ylabel=r'rest-spectrum relative $L^1$ error (%)',title=rf'$\lambda={lam}$')
        ax.legend(frameon=False,fontsize=8)
    save(fig,'resolution')
    fig,axes=plt.subplots(2,2,figsize=(10,6.3))
    for j,lam in enumerate([.25,.5]):
        s=spectrum[str(lam)];cv=s['tikhonov_cv']
        ax=axes[0,j];ax.errorbar(cv['alphas'],cv['mean'],yerr=cv['se'],fmt='o-',ms=3)
        ax.axvline(cv['selected_alpha'],ls='--',color='gray')
        ax.set(xscale='log',xlabel='Tikhonov strength',ylabel='held-out score / mode',title=rf'$\lambda={lam}$')
        ax=axes[1,j];cv=s['som_cv'];values=np.array(cv['cv'])
        ax.errorbar(cv['updates'],values.mean(axis=0),yerr=values.std(axis=0,ddof=1)/np.sqrt(len(values)),fmt='s-')
        ax.axvline(cv['selected_updates'],ls='--',color='gray')
        ax.set(xscale='log',xlabel='SOM updates / independent solution',ylabel='held-out score / mode')
    save(fig,'validation-v2')
    lines=['# 第二轮 bare DiagMC 改进与验证','',
        '1D、零温、单电子；t=ω₀=1，λ=g²/(2tω₀)。新结果与首轮数据分开保存。','',
        '## 基态与直接有效质量','',
        '| λ | E₀/t | Z₀ | 直接 m*/m₀ | VED k→0 质量 |','|---|---:|---:|---:|---:|']
    for lam in [.25,.5]:
        m=mass[str(lam)];g=m['ground']['primary'];f=m['primary'];ref=m['reference_curvature'][-1]
        lines.append(f"| {lam} | {g['E']:.7f} ± {g['E_error']:.7f} | {g['Z']:.6f} ± {g['Z_error']:.6f} | {f['mass_ratio']:.6f} ± {f['mass_ratio_error']:.6f} | {ref['mass_ratio']:.6f} |")
    lines+=['','质量由 ⟨K−J²⟩ 对 τ 的斜率给出，保留来自 Z(k) 曲率的截距。主拟合 τ∈[8,20]、合并时间箱至宽度1，选择在读取新参考曲率前固定。',
        '统计误差取三种块长和逐链删除 jackknife 中最大值。另列窗口、时间分箱和协方差收缩检查，不把统计误差当作系统误差上界。',
        '参考曲率用 k=0,0.01,0.02,0.04 与 14/16 代 VED 交叉检查；不同于首轮使用较大 k 网格的参考拟合。','',
        '![直接质量](results/report_02/direct-mass.svg)','',
        '## 谱函数：精确极点与随机优化','',
        'Tikhonov 使用精确非线性极点剖面优化；SOM 变体使用连续矩形的随机优化、非负面积变量投影及近最优解的集合平均。两者都保留相关 E/Z 先验和零至二阶谱矩。',
        'SOM 变体的更新及带协方差目标不同于原始论文，不声称逐项复现原实现。真实数据的模型选择结束后才读取 VED 谱。',
        '','| λ | 首轮非相干谱误差 | 新 Tikhonov | SOM 变体 |','|---|---:|---:|---:|']
    for lam in [.25,.5]:
        s=spectrum[str(lam)]
        lines.append(f"| {lam} | {100*old[str(lam)]['rest_l1_vs_reference']:.2f}% | {100*s['tikhonov_errors']['rest']:.2f}% | {100*s['som_errors']['rest']:.2f}% |")
    lines+=['','以上相对 L¹ 误差均在同一 η=0.25t、ω/t∈[−3.25,7] 下与独立 VED 比较。谱积分误差不是逐个峰位、峰宽的误差。',
        '蓝色带来自按链内统计块重采样，同时抽取独立 E/Z 相关误差，每次重新交叉验证选择正则化参数。它是分析流程的 16–84% 经验范围，不能覆盖所有参数化偏差。',
        '','![谱函数比较](results/report_02/spectra-v2.svg)','',
        '![正向传播子检查](results/report_02/forward-check.svg)','',
        '![频率分辨率评估](results/report_02/resolution.svg)','',
        '![独立链验证](results/report_02/validation-v2.svg)','',
        '## 复现与限制','',
        f'- 质量结果：`{args.mass}/summary.json`。',f'- 谱与带噪声验证：`{args.spectra}/summary.json`。',
        '- 新版保留源文件快照、输入 SHA-256、种子、Slurm 作业号与所有独立链的块数据。',
        '- 合成数据用于独立检验延拓，不用于真实数据的调参；VED 未输入图采样。',
        '- 更强耦合的扩展须以这轮质量稳定性和谱分辨率检查为依据，不能把尚未通过的细结构当成物理结论。','']
    (ROOT/'RESULTS_V2.md').write_text('\n'.join(lines).replace('results/report_02/',args.out.rstrip('/')+'/'))
    (out/'summary.json').write_text(json.dumps(dict(mass=mass,spectra=spectrum),indent=2)+'\n')
    print(out,flush=True)

if __name__=='__main__':main()
