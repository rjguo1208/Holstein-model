"""Independent-chain, time-window, covariance and k->0 mass checks."""
import argparse
from hashlib import sha256
import json
from pathlib import Path
import shutil
import sys
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from analysis import read_runs,summarize
from direct_mass import fit_direct_mass,mass_curve


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--inputs',nargs='+',default=['results/k0_01','results/k0_02'])
    parser.add_argument('--reference',default='results/reference_curvature_02')
    parser.add_argument('--out',required=True)
    args=parser.parse_args();out=ROOT/args.out;out.mkdir(parents=True,exist_ok=False)
    records={}
    for lam in [.25,.5]:
        label=f'lambda{lam:.2f}_k0.00_base'
        groups=[sorted(p for p in (ROOT/d).glob(label+'_s*') if p.is_dir()) for d in args.inputs]
        if any(not g for g in groups):raise ValueError('An input suite has no completed chains')
        paths=sum(groups,[]);rows,owners,metas=read_runs(paths);p=metas[0]
        primary=fit_direct_mass(rows,owners,p,8,20,time_bin_factor=4)
        windows=[fit_direct_mass(rows,owners,p,lower,20,time_bin_factor=4) for lower in [4,6,8,10,12]]
        scans=[fit_direct_mass(rows,owners,p,8,20,time_bin_factor=factor,shrinkage=shrink)
               for factor in [1,2,4,8] for shrink in [0.,.1,.3]]
        independent=[]
        for names,group in zip(args.inputs,groups):
            rr,oo,mm=read_runs(group)
            independent.append(dict(input=names,fit=fit_direct_mass(rr,oo,mm[0],8,20,time_bin_factor=4)))
        curve,error=mass_curve(rows,owners,p)
        tau=(np.arange(p['bins'])+.5)*p['tau_max']/p['bins']
        np.savez_compressed(out/f'lambda{lam:.2f}.npz',tau=tau,curvature=curve,error=error)
        ground=summarize(paths,out/'ground'/label)
        records[str(lam)]=dict(primary=primary,windows=windows,covariance_bin_scan=scans,
            independent_batches=independent,ground=ground,chains=len(paths),
            primary_choice='tau in [8,20], bins merged to width 1, free intercept; selected before reference comparison',
            window_span=[min(f['mass_ratio'] for f in windows[1:4]),max(f['mass_ratio'] for f in windows[1:4])])
        controls=[]
        for name in ['mu','tau','order']:
            paths=sorted(p for p in (ROOT/'results/controls_01').glob(f'lambda{lam:.2f}_k0.00_{name}_s*') if p.is_dir())
            rr,oo,mm=read_runs(paths)
            controls.append(dict(control=name,fit=fit_direct_mass(rr,oo,mm[0],8,20,time_bin_factor=4)))
        records[str(lam)]['sampling_controls']=controls
        print(lam,primary,flush=True)
    # Independent derivative benchmark is read after the estimator is fixed.
    reference=json.loads((ROOT/args.reference/'reference.json').read_text())
    for lam in [.25,.5]:
        refs=[]
        for nh in sorted(set(r['generations'] for r in reference)):
            points=sorted((r for r in reference if r['coupling']==lam and r['generations']==nh),key=lambda r:r['k'])
            for kmax in [.02,.04]:
                pts=[r for r in points if r['k']<=kmax]
                k=np.array([r['k'] for r in pts]);E=np.array([r['E'] for r in pts])
                X=np.column_stack([np.ones(len(k)),k*k,k**4])
                beta=np.linalg.lstsq(X,E,rcond=None)[0]
                refs.append(dict(generations=nh,kmax=kmax,mass_ratio=float(1/beta[1]),
                    max_energy_residual=float(max(abs(X@beta-E)))))
        records[str(lam)]['reference_curvature']=refs
    (out/'summary.json').write_text(json.dumps(records,indent=2)+'\n')
    sources=[ROOT/'analysis.py',ROOT/'direct_mass.py',Path(__file__)]
    for p in sources:
        target=out/'source'/p.relative_to(ROOT);target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
    (out/'provenance.json').write_text(json.dumps(dict(arguments=vars(args),
        sources={str(p.relative_to(ROOT)):sha256(p.read_bytes()).hexdigest() for p in sources}),indent=2)+'\n')

if __name__=='__main__':main()
