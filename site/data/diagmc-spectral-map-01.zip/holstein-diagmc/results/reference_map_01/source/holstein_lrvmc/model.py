from __future__ import annotations

from dataclasses import dataclass
from math import comb, sqrt
from itertools import combinations_with_replacement

import numpy as np
from scipy import sparse


@dataclass(frozen=True)
class Holstein:
    omega0: float = 1.0
    coupling: float = 0.5  # dimensionless lambda = g²/(2 t omega0)
    t: float = 1.0

    def __post_init__(self):
        if not np.all(np.isfinite([self.omega0, self.coupling, self.t])):
            raise ValueError("Parameters must be finite")
        if self.t <= 0 or self.omega0 <= 0 or self.coupling < 0:
            raise ValueError("Require t, omega0 > 0 and lambda >= 0")

    @property
    def g(self):
        return sqrt(2 * self.t * self.omega0 * self.coupling)

    def metadata(self):
        return dict(t=self.t, omega0=self.omega0, lambda_=self.coupling,
                    g=self.g, coupling_sign="-g", vacuum_energy=0.0)


CASES = {"A": Holstein(0.8, 0.25), "B": Holstein(1.0, 0.5),
         "C": Holstein(1.0, 1.0), "D": Holstein(0.8, 2.0)}
LITERATURE_E0 = {"B": -2.469684723933, "C": -2.998828186867}


def check_momentum(k: float, length: int):
    if not np.isfinite(k):
        raise ValueError("Momentum must be finite")
    m = k * length / (2 * np.pi)
    if abs(m - round(m)) > 1e-9:
        raise ValueError(f"k={k} is not an allowed momentum on L={length}")


def diagonal_energy(states: np.ndarray, length: int, k: float, model: Holstein):
    """Electron momentum is k minus the TOTAL phonon momentum (mod 2 pi)."""
    q = 2 * np.pi * np.arange(length) / length
    return (-2 * model.t * np.cos(k - states @ q)
            + model.omega0 * states.sum(axis=-1))


class MomentumBasis:
    """Complete finite-ring Fock space with a TOTAL phonon-number cutoff.

    There is exactly one electron momentum for each phonon occupation tuple
    in a fixed total-k sector. Dimension = binomial(L+Nph, Nph), not L times it.
    This is finite-size ED, not the infinite-lattice VED approximation.
    """

    def __init__(self, length: int, nph: int, max_dim: int = 200_000):
        if length < 1 or nph < 0:
            raise ValueError("Require L >= 1, Nph >= 0")
        self.length, self.nph = int(length), int(nph)
        self.dim = comb(length + nph, nph)
        if self.dim > max_dim:
            raise ValueError(f"ED dimension {self.dim:,} exceeds max_dim={max_dim:,}; use VMC")
        states = np.zeros((self.dim, length), dtype=np.int32)
        j = 1
        for n in range(1, nph + 1):
            for modes in combinations_with_replacement(range(length), n):
                states[j] = np.bincount(modes, minlength=length)
                j += 1
        self.states = states
        self.index = {tuple(s): i for i, s in enumerate(states)}
        self.zero_index = 0
        rows, cols, vals = [], [], []
        for i, s in enumerate(states):
            if s.sum() == nph:
                continue
            for q in range(length):
                target = s.copy()
                target[q] += 1
                j = self.index[tuple(target)]
                value = -sqrt((int(s[q]) + 1) / length)
                rows.extend([i, j]); cols.extend([j, i]); vals.extend([value, value])
        self.interaction = sparse.csr_matrix((vals, (rows, cols)), shape=(self.dim, self.dim))

    def hamiltonian(self, k: float, model: Holstein):
        check_momentum(k, self.length)
        return (sparse.diags(diagonal_energy(self.states, self.length, k, model))
                + model.g * self.interaction).tocsr()


class VEDBasis:
    """Bonca-Trugman infinite-lattice basis, generated with <= Nh operations.

    A state is a sorted tuple of phonon POSITIONS relative to the electron,
    with repeated positions representing multiple quanta. No real-space ring
    or phonon-momentum grid is introduced. Full annihilation/hopping matrix
    elements are included after generation and projected onto this space.
    """

    def __init__(self, generations: int, max_dim: int = 4_000_000):
        if generations < 1:
            raise ValueError("generations must be positive")
        self.generations = int(generations)
        states, index, frontier = [()], {(): 0}, [()]
        for _ in range(generations):
            new = []
            for s in frontier:
                targets = (tuple(sorted(s + (0,))), tuple(r - 1 for r in s),
                           tuple(r + 1 for r in s))
                for target in targets:
                    if target not in index:
                        if len(states) >= max_dim:
                            raise ValueError(f"VED exceeded max_dim={max_dim:,}")
                        index[target] = len(states)
                        states.append(target); new.append(target)
            frontier = new
        self.dim, self.zero_index = len(states), 0
        nph = np.fromiter((len(s) for s in states), dtype=float, count=self.dim)
        rows, cols, vals, sr, sc = [], [], [], [], []
        for i, s in enumerate(states):
            j = index.get(tuple(sorted(s + (0,))))
            if j is not None:
                v = -sqrt(s.count(0) + 1)
                rows.extend([i, j]); cols.extend([j, i]); vals.extend([v, v])
            j = index.get(tuple(r - 1 for r in s))
            if j is not None:
                sr.append(j); sc.append(i)
        self.number = sparse.diags(nph, format="csr")
        self.interaction = sparse.csr_matrix((vals, (rows, cols)), shape=(self.dim, self.dim))
        self.shift = sparse.csr_matrix((np.ones(len(sr)), (sr, sc)), shape=(self.dim, self.dim))

    def hamiltonian(self, k: float, model: Holstein):
        if not np.isfinite(k):
            raise ValueError("Momentum must be finite")
        phase = np.exp(-1j * k)
        if abs(phase.imag) < 1e-14:
            phase = phase.real
        return (model.omega0 * self.number + model.g * self.interaction
                - model.t * (phase * self.shift + np.conj(phase) * self.shift.T)).tocsr()
