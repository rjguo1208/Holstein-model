from __future__ import annotations

from dataclasses import dataclass
import numpy as np
from scipy.linalg import eigh_tridiagonal
from scipy.sparse.linalg import eigsh


@dataclass
class PoleSpectrum:
    energies: np.ndarray
    weights: np.ndarray

    def __post_init__(self):
        self.energies = np.asarray(self.energies, dtype=float)
        self.weights = np.asarray(self.weights, dtype=float)
        if self.energies.ndim != 1 or self.weights.shape != self.energies.shape:
            raise ValueError("Pole energies and weights must be one-dimensional and aligned")
        if not np.all(np.isfinite(self.energies)) or not np.all(np.isfinite(self.weights)):
            raise ValueError("Nonfinite pole data")
        if np.any(self.weights < -1e-13):
            raise ValueError("Negative spectral weight")
        order = np.argsort(self.energies)
        self.energies = self.energies[order]
        self.weights = np.maximum(self.weights[order], 0)

    def broaden(self, omega, eta):
        if eta <= 0:
            raise ValueError("eta must be positive")
        omega = np.asarray(omega)
        out = np.zeros_like(omega, dtype=float)
        for start in range(0, len(self.energies), 128):
            es = self.energies[start:start + 128]
            ws = self.weights[start:start + 128]
            out += (eta / np.pi / ((omega[:, None] - es) ** 2 + eta ** 2)) @ ws
        return out

    def moment(self, order):
        """UNBROADENED moment. Lorentzian broadening destroys higher moments."""
        return float(self.weights @ self.energies ** order)

    def lowest(self, weight_floor=1e-14, cluster_tolerance=1e-9):
        indices = np.flatnonzero(self.weights > weight_floor)
        if not len(indices):
            raise ValueError("Spectrum contains no resolved pole")
        i = indices[0]
        near = np.abs(self.energies - self.energies[i]) < cluster_tolerance
        return float(self.energies[i]), float(self.weights[near].sum())

    def save(self, path):
        np.savez_compressed(path, energies=self.energies, weights=self.weights)


def ground_state(H, source_index=0, tol=1e-11):
    if H.shape[0] <= 3:
        ev, U = np.linalg.eigh(H.toarray())
        E, psi = ev[0], U[:, 0]
    else:
        rng = np.random.default_rng(123)
        v0 = rng.normal(size=H.shape[0])
        ev, U = eigsh(H, k=1, which="SA", tol=tol, v0=v0, ncv=min(40, H.shape[0]))
        E, psi = ev[0], U[:, 0]
    residual = np.linalg.norm(H @ psi - E * psi)
    return float(E.real), float(abs(psi[source_index]) ** 2), float(residual), psi


def lanczos_spectrum(H, steps=500, source_index=0, reorthogonalize=True,
                     max_storage_mb=2048):
    """Hermitian Lanczos spectral measure, preserving the source norm.

    Large VED runs may explicitly disable reorthogonalization to avoid O(D*m)
    storage/O(D*m²) work; convergence in the recursion length must then be
    assessed separately. Ground E/Z always come from an independent eigensolve.
    """
    steps = min(int(steps), H.shape[0])
    if steps < 1:
        raise ValueError("steps must be positive")
    dtype = np.result_type(H.dtype, np.float64)
    if reorthogonalize and H.shape[0] * steps * np.dtype(dtype).itemsize > max_storage_mb * 1024 ** 2:
        raise MemoryError("Lanczos storage limit: reduce steps or explicitly disable reorthogonalization")
    Q = np.empty((steps, H.shape[0]), dtype=dtype) if reorthogonalize else None
    q = np.zeros(H.shape[0], dtype=dtype); q[source_index] = 1
    old = np.zeros_like(q)
    beta_old = 0.
    alpha, beta = [], []
    for j in range(steps):
        if Q is not None:
            Q[j] = q
        w = H @ q - beta_old * old
        a = np.vdot(q, w)
        if abs(a.imag) > 1e-9:
            raise ValueError("Hamiltonian is not Hermitian")
        w -= a.real * q
        if Q is not None:
            for _ in range(2):
                w -= (Q[:j + 1].conj() @ w) @ Q[:j + 1]
        b = float(np.linalg.norm(w))
        alpha.append(float(a.real))
        if b < 1e-12 or j == steps - 1:
            break
        beta.append(b)
        old, q, beta_old = q, w / b, b
    if len(alpha) == 1:
        return PoleSpectrum(np.array(alpha), np.ones(1)), np.array(alpha), np.array(beta)
    ev, U = eigh_tridiagonal(alpha, beta)
    return PoleSpectrum(ev, U[0] ** 2), np.array(alpha), np.array(beta)


def comparison(reference, candidate, omega, eta, ref_ez=None, candidate_ez=None):
    omega = np.asarray(omega)
    if omega.ndim != 1 or len(omega) < 2 or np.any(np.diff(omega) <= 0):
        raise ValueError("Frequency grid must be increasing")
    er, zr = reference.lowest() if ref_ez is None else ref_ez
    ec, zc = candidate.lowest() if candidate_ez is None else candidate_ez
    ar, ac = reference.broaden(omega, eta), candidate.broaden(omega, eta)
    integral = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
    mass = integral(ar, omega)
    rest_r = ar - zr * eta / np.pi / ((omega - er) ** 2 + eta ** 2)
    rest_c = ac - zc * eta / np.pi / ((omega - ec) ** 2 + eta ** 2)
    rest_mass = integral(rest_r, omega)
    d = float(integral(abs(ac - ar), omega) / mass)
    dr = float(integral(abs(rest_c - rest_r), omega) / rest_mass) if rest_mass > 1e-10 else None
    de, dz = float(ec - er), float(zc - zr)
    return dict(E_reference=er, E_candidate=ec, Z_reference=zr, Z_candidate=zc,
                delta_E=de, delta_Z=dz, spectral_l1=d, rest_spectral_l1=dr,
                weight_reference=reference.moment(0), weight_candidate=candidate.moment(0),
                window_weight_reference=float(mass), eta=float(eta),
                energy_agreement=abs(de) < 1e-3,
                residue_agreement=abs(dz) < max(1e-4, .02 * zr),
                spectrum_agreement=d < .03,
                rest_spectrum_agreement=dr is not None and dr < .05)
