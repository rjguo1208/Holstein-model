"""Archived numerical reference routines for standalone reproduction."""
