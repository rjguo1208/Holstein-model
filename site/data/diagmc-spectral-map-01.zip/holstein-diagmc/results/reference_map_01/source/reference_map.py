"""An explicitly VED/Lanczos reference map, independent of DiagMC continuation."""
from __future__ import annotations
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import sys
import time

import numpy as np
from scipy.linalg import eigh_tridiagonal

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out', required=True)
parser.add_argument('--project', default=str(ROOT.parent / 'NNQS/holstein_lrvmc'))
parser.add_argument('--points', type=int, default=41)
parser.add_argument('--generations', type=int, nargs='+', default=[14, 16])
parser.add_argument('--check-generation', type=int, default=18)
parser.add_argument('--steps', type=int, default=400)
parser.add_argument('--check-steps', type=int, default=800)
parser.add_argument('--couplings', type=float, nargs='+', default=[.25, .5])
args = parser.parse_args()
if args.points < 5 or args.steps < 2 or args.check_steps < args.steps:
    parser.error('Need at least five k points and check_steps >= steps >= 2')
project = Path(args.project).resolve()
sys.path.insert(0, str(project))
from holstein_lrvmc.model import Holstein, VEDBasis
from holstein_lrvmc.spectral import PoleSpectrum, lanczos_spectrum

out = Path(args.out).resolve()
out.mkdir(parents=True, exist_ok=False)
start = time.monotonic()
kpath = np.linspace(0., np.pi, args.points)
axis = np.linspace(-3.25, 5.5, 701)
etas = np.array([.15, .25, .5, 1.])
checks = np.unique(np.round(np.linspace(0, args.points - 1, 5)).astype(int))
sources = [Path(__file__), project/'holstein_lrvmc/model.py',
           project/'holstein_lrvmc/spectral.py']
provenance = dict(method='infinite-lattice VED + Lanczos; NOT DiagMC',
    argv=sys.argv, python=sys.version, numpy=np.__version__,
    job_id=os.environ.get('SLURM_JOB_ID'), source_sha256={})
for source in sources:
    dest = out/'source'/source.name
    dest.parent.mkdir(exist_ok=True)
    shutil.copyfile(source, dest)
    provenance['source_sha256'][str(source)] = sha256(source.read_bytes()).hexdigest()
(out/'provenance.json').write_text(json.dumps(provenance, indent=2)+'\n')
spectra = {}
records = []
dimensions = {}
for nh in sorted(set(args.generations + [args.check_generation])):
    basis = VEDBasis(nh)
    dimensions[str(nh)] = basis.dim
    indices = np.arange(args.points) if nh in args.generations else checks
    for coupling in args.couplings:
        model = Holstein(omega0=1., coupling=coupling, t=1.)
        for ik in indices:
            k = kpath[ik]
            H = basis.hamiltonian(k, model)
            steps = args.check_steps if ik in checks else args.steps
            spectrum, alpha, beta = lanczos_spectrum(H, steps=steps, reorthogonalize=False)
            path = out/f'lambda{coupling:.2f}_nh{nh}_ik{ik:03d}.npz'
            np.savez_compressed(path, energies=spectrum.energies, weights=spectrum.weights,
                alpha=alpha, beta=beta, k=k, t=model.t, omega0=model.omega0,
                coupling=coupling, g=model.g, generations=nh)
            spectra[coupling, nh, ik] = np.array([spectrum.broaden(axis, eta) for eta in etas])
            exact = np.array([1., -2*np.cos(k), 4*np.cos(k)**2 + model.g**2])
            measured = np.array([spectrum.moment(j) for j in range(3)])
            record = dict(coupling=coupling, generations=nh, ik=int(ik), k=float(k),
                moments=measured.tolist(), moment_residuals=(measured-exact).tolist(),
                lanczos_steps=len(alpha), weights_min=float(spectrum.weights.min()))
            assert np.max(np.abs(measured-exact)) < 1e-9
            if ik in checks:
                ev, U = eigh_tridiagonal(alpha[:args.steps], beta[:args.steps-1])
                short = PoleSpectrum(ev, U[0]**2)
                record['step_relative_l1'] = [
                    float(np.trapezoid(abs(short.broaden(axis, eta)-spectra[coupling, nh, ik][j]), axis) /
                          np.trapezoid(spectra[coupling, nh, ik][j], axis))
                    for j, eta in enumerate(etas)]
            records.append(record)
            if ik % 10 == 0:
                print(f'Nh={nh}, lambda={coupling}, k/pi={k/np.pi:.2f}, '
                      f'elapsed={time.monotonic()-start:.1f}s', flush=True)
    del H, basis

main_nh = max(args.generations)
convergence = []
for coupling in args.couplings:
    A = np.stack([spectra[coupling, main_nh, i] for i in range(args.points)], axis=1)
    # A.shape = (eta, k, energy). No per-column normalization or energy shift.
    np.savez_compressed(out/f'lambda{coupling:.2f}_map.npz',
        k=kpath, energy=axis, eta=etas, A=A, t=1., omega0=1., coupling=coupling,
        g=np.sqrt(2*coupling), generations=main_nh,
        method='VED/Lanczos reference, not DiagMC')
    for lower, upper, indices in [(min(args.generations), main_nh, range(args.points)),
                                  (main_nh, args.check_generation, checks)]:
        for ik in indices:
            ref = spectra[coupling, upper, ik]
            diff = spectra[coupling, lower, ik] - ref
            convergence.append(dict(coupling=coupling, lower=lower, upper=upper,
                k=float(kpath[ik]), relative_l1=[
                    float(np.trapezoid(abs(d), axis)/np.trapezoid(r, axis))
                    for d, r in zip(diff, ref)],
                max_absolute=np.max(abs(diff), axis=1).tolist()))
summary = dict(method=provenance['method'], t=1., omega0=1.,
    coupling_definition='lambda=g^2/(2*t*omega0)', couplings=args.couplings,
    k_path='Gamma to X: 0 to pi (a=1)', k_points=args.points,
    energy_zero='electron and phonon vacuum, common to every k',
    energy_window=[float(axis[0]), float(axis[-1])], energy_points=len(axis),
    eta=etas.tolist(), main_generations=main_nh, dimensions=dimensions,
    no_reorthogonalization=True, step_counts=[args.steps, args.check_steps],
    records=records, convergence=convergence, elapsed_seconds=time.monotonic()-start,
    limitations=['finite variational space; spectral continuum represented by discrete poles',
                 'basis convergence at Nh18 checked at five momenta, not all momenta',
                 'Lorentzian broadening is display resolution, not a physical lifetime',
                 'plotted finite energy window does not contain all Lorentzian tails'])
(out/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(f'Complete: {out}, {time.monotonic()-start:.1f}s', flush=True)
