# 第二轮实施记录

本轮固定 1D、零温、单电子，t=ω₀=1、λ=0.25,0.5。
先检查基态和质量，再检查谱函数的信息量；更强耦合的扩展以质量与谱的验收结果为条件。

## 已实现的分析

- `direct_mass.py`：由 ⟨K−J²⟩ 的长虚时斜率计算逆质量，保留非零截距。
  时间分箱、块长、逐链删除、拟合窗口与协方差收缩分别检查。
- `scripts/mass_v2.py`：独立批次对照、既有 μ/T/阶数控制，以及真正小 k 的 VED 曲率对照。
- `spectral_nonlinear.py`：基态极点的精确非线性剖面优化；连续矩形 SOM 变体。
  后者使用中心/宽度/增删更新、非负面积变量投影和多个近最优解的平均。
  它借鉴 Mishchenko 等论文附录 B 的框架，目标函数和更新并非原文逐项复现。
- `scripts/spectra_v3.py`：独立链留出验证、每次重新选择正则化强度的块 bootstrap、
  相关 E/Z 误差传播、无噪声及带噪声合成基准，以及固定展宽的分辨率扫描。
  真实数据的参数选择完成后才读取 VED 谱。
- `scripts/diagnostics.py`：以精确箱积分将 VED 谱正向变换，检查真实 G(τ) 与协方差。
- `scripts/quality_v2.py`：报告预先说明的 1% 质量与 η=0.25t 下 10% 非相干谱目标，
  失败时明确阻止把扩展标记为已通过，不通过加大展宽冒充原分辨率目标达成。

## 新采样与自动后处理

`run_suite.py` 新增耦合、声子频率、链数、块数、块长、种子偏移和条件积分频率参数。
默认参数保持首轮计算的定义。两批新采样分别为：

```bash
./scripts/python.sh scripts/run_suite.py k0 --out results/k0_02 \
  --jobs 8 --chains 8 --seed-offset 153000000
./scripts/python.sh scripts/run_suite.py spectral_data --out results/spectral_data_02 \
  --jobs 8 --chains 16 --seed-offset 97000000
```

每条新链仍为 4,800 万生产步。主长虚时每个耦合新增8链；谱数据每个耦合新增16链。
这是增加独立信息和检验协方差稳定性的计算，不预先保证精细谱误差能降至10%。

`scripts/finish_v2.slurm` 以两个采样作业均成功为依赖，再合并长虚时数据、执行新版谱分析、
生成报告与质量门槛 JSON。任何输入未完成即停止；已有结果目录不会被静默覆盖。
只有门槛通过后，`scripts/expand_v2.py` 才启动 λ=0.75,1.0,1.5 的新采样和16/18代独立参考；
若不通过，则写明未启动及原因。降低 ω₀/t 和外部声子扇区仍属于此后需要验证的阶段。
新数据完成前的实际分析保存在 `mass_direct_02_initial`、`spectral_03`，
`spectral_pilot_03` 仅是较少随机优化解与重采样次数的试运行。

## 验证

- C++ 独立差分验证图权重对 k 的一、二阶导数，确认 J²−K 的符号和系数。
- Python 检验带非零截距的质量提取、矩形谱的双重积分、精确非线性极点及谱矩、
  展宽归一化，以及随机优化在自由电子极限下不能产生虚假非相干权重。
- 结果中的统计标准误差、窗口依赖、算法集合波动和参考误差分别报告。
  Bootstrap 的经验范围不包括未建模的谱参数化偏差。

方法来源：
[Ragni 的 Holstein DiagMC 学位论文](https://amslaurea.unibo.it/id/eprint/22104/1/ragni-diagrammatic_monte_carlo_study_of_the_holstein_polaron.pdf)，
[Mishchenko 等，附录 B](https://arxiv.org/pdf/cond-mat/9910025)。
