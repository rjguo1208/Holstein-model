# 1D Holstein：零温、单电子 bare DiagMC

本项目实际采样裸格林函数展开，包含先后、嵌套和交叉声子线。
先从长虚时间计算 (k=0) 的 (E_0,Z)，再从小动量色散计算有效质量，
最后对独立测量的虚时间数据作带误差检查的谱函数重建。
数值结果、图和限制见 [RESULTS.md](RESULTS.md)。

第二轮的直接质量、精确极点延拓、SOM 变体和分辨率检查见 [RESULTS_V2.md](RESULTS_V2.md)，
实施与自动后处理流程见 [IMPROVEMENTS.md](IMPROVEMENTS.md)。
本轮新增采样的完成状态单独记录；尚在排队的数据不计入已公布的分析。

## 模型、单位与计算对象

\[
H=-t\sum_i(c^\dagger_{i+1}c_i+\mathrm{h.c.})
  +\omega_0\sum_i b_i^\dagger b_i
  +g\sum_i n_i(b_i^\dagger+b_i),\qquad
\lambda=\frac{g^2}{2t\omega_0}.
\]

取 \(\hbar=a=t=\omega_0=1\)，真空能量为零，
\(\lambda=0.25,0.5\)，对应 \(g=\sqrt{0.5},1\)。
电子色散 \(\varepsilon_k=-2t\cos k\)，自由质量 \(m_0=1/(2t)=0.5\)。
动量的单位是弧度，直接在无限晶格的布里渊区连续积分，未引入有限环或动量网格。

\[
\mathcal G_\mu(k,\tau)
=\langle\mathrm{vac}|c_k e^{-(H-\mu N_e)\tau}c_k^\dagger|\mathrm{vac}\rangle.
\]

这里采用正的传播子定义；常规费米虚时格林函数多一个整体负号。
\(\mu\) 是辅助采样参数，\(\tau_{\max}\) 是测量范围，**不是有限温度的逆温度**。

## 图空间与详细平衡

构型是 \(C=(\tau,\{u_\ell,v_\ell,q_\ell\}_{\ell=1}^n)\)，
\(0<u_\ell<v_\ell<\tau\)。声子线作为无标号集合计数；按有序电子顶点看，每种配对只计一次。
各段电子动量为 \(k-\sum_{\ell\text{ active}}q_\ell\)，权重为

\[
W(C)=g^{2n}e^{-S(C)},\quad
S=\sum_j(\varepsilon_{p_j}-\mu)\Delta\tau_j
   +\omega_0\sum_\ell(v_\ell-u_\ell).
\]

每条声子的积分测度为 \(dq/(2\pi)\)。没有闭合费米交换回路，所有权重非负。
\(n\) 是整张图的声子线数，并非同一时刻的声子数。

固定更新概率为：插入 0.30、删除 0.30、动量 0.15、端点 0.10、外部虚时 0.15。
空图、阶数上限处不能进行的更新保留为拒绝步；测量包含这些步。
插入时均匀选 \(u\in(0,\tau)\)、\(q\in[-\pi,\pi)\)，并从截断指数分布选长度

\[
p(\ell\mid u)=\frac{\omega_0e^{-\omega_0\ell}}
 {1-e^{-\omega_0(\tau-u)}},\qquad 0<\ell<\tau-u.
\]

逆更新从 \(n+1\) 条声子线中等概率删除一条，因此

\[
R_\mathrm{add}=
g^2 e^{-(S'-S)}\frac{\tau}{n+1}
\frac{1-e^{-\omega_0(\tau-u)}}{\omega_0}
e^{\omega_0\ell},\qquad P_\mathrm{acc}=\min(1,R).
\]

删除比率是相应插入比率的逆。端点更新允许跨越其他顶点，因此交叉图可被访问。
整体伸缩 \(\tau'=r\tau\)、\(u'=ru,v'=rv\) 包含 \(r^{2n}\) 的端点雅可比；
若在 \(\log\tau\) 中对称提议，另有一个 \(r\) 的提议比率。
空图的外部虚时用精确截断指数热浴更新。

## 绝对归一化与测量

一次运行同时采样 \(0<\tau<T\)。令 \(N_b\) 是第 \(b\) 个虚时箱的访问数，
\(N_0\) 是所有虚时上零阶图的访问数，则

\[
\overline{\mathcal G}_{\mu,b}
=\frac{I_0}{\Delta\tau}\frac{N_b}{N_0},\qquad
I_0=\int_0^T e^{-(\varepsilon_k-\mu)\tau}d\tau.
\]

这估计的是**箱平均**。长时间拟合使用完整箱积分：

\[
\overline{\mathcal G}_{\mu,b}
=Z e^{-(E-\mu)\tau_b}
\frac{\sinh[(E-\mu)\Delta\tau/2]}{(E-\mu)\Delta\tau/2}.
\]

所有虚时箱共享 \(N_0\)，因此必须保留协方差。误差由 block jackknife 给出，
并比较原始、二倍和四倍块长；主结果报告其中最大的标准误差。
长时间的直接能量估计量
\([\sum_j\varepsilon_{p_j}\Delta\tau_j+\omega_0\sum_\ell(v_\ell-u_\ell)-2n]/\tau\)
另作交叉检查。

有效质量使用独立动量链，拟合 \(E(k)=b_0+c_2k^2+c_4k^4\)，
\(m^*/m_0=t/c_2\)，并缩小动量窗口检查曲率稳定性。

谱函数的数据使用额外的条件积分估计量。固定 \(x=u/\tau,y=v/\tau,n,q\) 时，

\[
p(\tau\mid x,y,n,q)\propto\tau^{2n}e^{-r\tau},
\quad r=S/\tau>0,\quad 0<\tau<T.
\]

把单次虚时直方图命中替换为这个截断 Gamma 分布对各箱的精确积分。
这不改变图的采样，也不使用参考解；当前实现要求 \(\mu<-2t\)。

## 谱函数的含义与限制

\[
\mathcal G_\mu(k,\tau)=\int d\omega\,A(k,\omega)e^{-(\omega-\mu)\tau},\qquad
A(k,\omega)=Z_k\delta(\omega-E_k)+A_\mathrm{rest}(k,\omega).
\]

非负谱权重由带二阶差分惩罚的最小二乘求解，使用数据协方差，并约束未展宽谱的精确矩
\(M_0=1,M_1=\varepsilon_k,M_2=\varepsilon_k^2+g^2\)。
基态极点的位置和权重允许在**独立长虚时运行**给出的相关误差内变化。
连续谱参数化保留低于单声子散射阈值的可能权重，没有先验删去可能的束缚激发态。

四条独立链逐条留出验证；选择预测分数在最小值一个标准误差以内的最大正则化强度。
再检查频率截止、频率网格、协方差保留阈值以及相关噪声扰动。
图中使用 Lorentz 展宽 \(\eta=0.25t\)，它是显示分辨率，**不是计算得到的寿命**。
24 次高斯扰动给出的是固定分析选择下的敏感性带，不是完整的置信区间。
解析延拓的细节结构不能由一条看起来平滑的曲线证实。

## 运行

需要 C++17 编译器，以及 Python 3.11+、NumPy、SciPy、Matplotlib 和 pytest。
实际环境版本记录在 `requirements.txt`。本机脚本使用既有科学 Python 环境；
其他机器可设置 `HOLSTEIN_PYTHON=/path/to/python`。

```bash
make all test
./scripts/python.sh -m pytest -q tests/test_analysis.py
./scripts/python.sh scripts/run_suite.py validation --out results/validation_new --jobs 4
./scripts/python.sh scripts/run_suite.py k0 --out results/k0_new --jobs 4
./scripts/python.sh scripts/run_suite.py dispersion --out results/dispersion_new --jobs 4 \
  --momenta 0.10 0.15 0.20 0.30 0.45
```

单条链示例：

```bash
./build/diagmc --t 1 --omega 1 --g 1 --k 0 --mu -2.58 \
  --tau-max 24 --bins 96 --max-order 96 --warmup 500000 \
  --blocks 240 --steps-per-block 200000 --thin 5 --seed 101 \
  --out results/example_chain
```

集群运行通过 `sbatch -A ACCOUNT -p PARTITION scripts/run.slurm ...` 提交。
每套脚本拒绝覆盖已有输出；源文件快照、源文件和可执行文件 SHA-256、种子及作业号写入结果目录。
`scripts/mass.py`、`scripts/spectra_cv.py`、`scripts/report.py` 使用本次已命名的结果目录，
若要分析一套新结果，应先相应调整脚本路径。

`scripts/reference*.py` 只用于独立 VED/Lanczos 对照，调用同一工作区另一个项目的参考实现。
该依赖不是 bare DiagMC 求解器的依赖；其源文件哈希单独保存，参考结果从未输入图采样。

## 文件与验证

| 文件 | 作用 |
|---|---|
| `src/diagmc.hpp` | 连续时间和动量的裸图采样、详细平衡 |
| `src/conditional.hpp` | 外部虚时的条件积分测量 |
| `src/main.cpp` | 命令行、独立块和阶数诊断 |
| `analysis.py` | 零阶归一化、相关拟合、jackknife、解析极限 |
| `spectral_cv.py` | 非负谱重建与独立链验证 |
| `continuation.py` | 精确箱积分核及保留的第一版解析延拓 |
| `tests/` | 运动学、更新比率、雅可比、条件积分、合成谱与统计检验 |
| `results/` | 原始块数据、输入快照、诊断和分析产物 |

解析极限检验包括自由电子、原子极限完整传播子和有限跳跃的一阶展开。
合成谱测试检验逆问题代码的矩与积分核，不把它当成真实谱可被唯一重建的证明。

## 文献

- [Greitemann & Pollet, Lecture notes on Diagrammatic Monte Carlo (2018)](https://arxiv.org/abs/1711.03044)：裸图展开和更新的背景。
- [Fehske & Trugman, Numerical solution of the Holstein polaron problem (2007)](https://arxiv.org/abs/cond-mat/0611020)：Holstein 变分精确对角化与谱的背景。
- [Schumm, Yang & Sandvik, Cross Validation in Stochastic Analytic Continuation (2024)](https://arxiv.org/abs/2406.06763)：用留出虚时数据选择谱参数化。这里使用的是非负 Tikhonov 求解器，并非该文的 SAC 实现。
