# Completed sampling and current precision — 2026-09-18

All five queued jobs completed with exit code 0:0. The actual DiagMC map is now
available, still explicitly preliminary. The program-completion state is not
a certificate of spectral accuracy.

| Work | Job | Partition/node | Runtime |
|---|---|---|---|
| 17-point spectral map data | 20826452 | highmem / b000 | 3m02s |
| Map continuation and figures | 20826455 | highmem / b000 | 2m29s |
| New k=0 spectral data | 20825973 | debug / a004 | 56s |
| New k=0 long-time data | 20825985 | debug / a004 | 37s |
| Combined k=0 analysis | 20826180 | shared / a240 | 13m32s |

The map contains 17 momenta × 2 couplings × 4 independent chains, with 24 million
production steps per chain: 3,264,000,000 steps. All raw block counts and
completion flags, unique seeds, source hashes and continuation input hashes
were verified. No order-cap rejection occurred. All saved maps and bootstrap
arrays are finite and nonnegative (bootstrap intervals are finite).

The map continuation uses no VED input or independently imposed E/Z pole. The
post-selection audit compares only the nine exactly coincident reference
momenta k/pi=0,1/8,...,1, with no reference interpolation. At eta=.25t the
whole-spectrum relative L1 error ranges 5.0–37.2% (lambda=.25) and 11.8–43.6%
(lambda=.5). At eta=t these ranges are 0.44–2.57% and 1.37–5.11%.

These numbers include the ground-state peak and cannot be substituted for
incoherent-spectrum errors. They cover only the plotted energy window and
the nine compared momenta, not every frequency or all 17 k points. Large
held-out prediction scores (up to 45.1 / 31.7) indicate unresolved statistics
or covariance issues at some momenta. Eight block bootstrap replicates do not
cover all inverse-problem bias. Fine features remain unvalidated.

The merged long-time analysis gives:

| lambda | E0/t | Z0 | m*/m0 |
|---|---|---|---|
| .25 | -2.2287524 ± .0001178 | .86834 ± .00101 | 1.152053 ± .000396 |
| .5 | -2.4698465 ± .0001906 | .73625 ± .00129 | 1.350906 ± .000743 |

Mass values pass the predefined check, with a separate fit-window study;
the lambda=.25 mass fit still has chi²/dof≈2.25. The selected k=0 continuation
methods have incoherent-spectrum L1 errors 24.1% and 24.5% at eta=.25t,
so the previous 10% fine-spectrum target fails. The stronger-coupling expansion
correctly remained unstarted.

## Reproduction

The main map-data archive contains conditional summaries, numerical source
snapshots, final spectra and the independent audit. Raw chains are split into
two additional archives by coupling; unpack them into the same directory for
the full raw-data audit. Reference data are
in the separately retained diagmc-spectral-map-01.zip. The completed k=0 archive
contains new chains, current analysis source, reference curves, merged results
and reports. For merged k=0 reproduction also unpack the first
holstein-diagmc.zip, which supplies the older independent chains.

~~~bash
./scripts/python.sh scripts/continue_map.py \
  --data results/map_data_01 --out results/map_diagmc_reproduced --points 17 --bootstrap 8
./scripts/python.sh scripts/mass_v2.py --out results/mass_direct_reproduced
./scripts/python.sh scripts/spectra_v3.py --data results/spectral_data_02 \
  --prior-data results/mass_direct_reproduced/ground --out results/spectral_reproduced
~~~

Website sources are generated with:

~~~bash
./scripts/python.sh scripts/site_revision.py --mass results/mass_direct_02 \
  --spectra results/spectral_04 --figures results/report_02_completed --sampling-status complete
./scripts/python.sh scripts/site_map.py --diagmc results/map_diagmc_01
~~~
