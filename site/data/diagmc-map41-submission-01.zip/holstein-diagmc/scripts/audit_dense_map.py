"""Audit the measured 41-point map and compare every k to the independent VED reference."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--data', type=Path, required=True)
    parser.add_argument('--map', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--reference', type=Path, default=ROOT/'results/reference_map_01')
    args = parser.parse_args()
    grid = json.loads((args.data/'grid_manifest.json').read_text())
    provenance = json.loads((args.map/'provenance.json').read_text())
    assert provenance['complete'] and len(provenance['inputs']) == 82
    for name, digest in provenance['inputs'].items():
        p = Path(name)
        if not p.is_absolute():
            p = ROOT/p
        # Paths in the saved provenance remain useful after extracting elsewhere.
        if not p.exists():
            suffix = name.split(args.data.name+'/', 1)[1]
            p = args.data/suffix
        assert sha256(p.read_bytes()).hexdigest() == digest
    for name, digest in provenance['sources'].items():
        assert sha256((args.map/'source'/name).read_bytes()).hexdigest() == digest
    raw, new, reused = [], [], []
    for point in grid['points']:
        folder = args.data/f'ik{point["index"]:03d}'
        manifest = json.loads((folder/'manifest.json').read_text())
        for name, digest in manifest['source_hashes'].items():
            assert sha256((folder/'source'/name).read_bytes()).hexdigest() == digest
        files = sorted(folder.glob('lambda*/run.json'))
        assert len(files) == 8
        runs = [json.loads(file.read_text()) for file in files]
        assert len({r['seed'] for r in runs}) == 8
        for file, r in zip(files, runs):
            assert r['complete'] and abs(r['k']-point['k']) < 1e-12
            assert r['t'] == r['omega'] == 1 and r['mu'] == -2.8
            assert (r['tau_max'], r['bins'], r['max_order']) == (12, 96, 96)
            assert (r['blocks'], r['steps_per_block'], r['rb_thin']) == (240, 100000, 100)
            for name in ['blocks.csv', 'rb_blocks.csv']:
                assert (file.parent/name).read_bytes().count(b'\n') == r['blocks']+1
        for lam in grid['couplings']:
            assert sum(np.isclose(r['g']**2/2, lam) for r in runs) == 4
        if point['mode'] == 'reuse':
            for name, digest in point['file_hashes'].items():
                assert sha256((folder/name).read_bytes()).hexdigest() == digest
            reused.extend(runs)
        else:
            assert sorted(r['seed'] for r in runs) == sorted(point['seeds'])
            new.extend(runs)
        raw.extend(runs)
    assert len(raw) == len({r['seed'] for r in raw}) == 328
    assert len(new) == 256 and len(reused) == 72
    report = dict(captured_utc=datetime.now(timezone.utc).isoformat(),
        k_points=41, chains=len(raw), complete_chains=sum(r['complete'] for r in raw),
        new_chains=len(new), reused_chains=len(reused), new_points=32, reused_points=9,
        production_steps=sum(r['blocks']*r['steps_per_block'] for r in raw),
        new_production_steps=sum(r['blocks']*r['steps_per_block'] for r in new),
        cap_attempts=sum(r['cap_attempts'] for r in raw),
        source_and_input_hashes_verified=True, raw_block_counts_verified=True,
        reused_file_hashes_verified=True, unique_random_seeds=True,
        spectral_resolution_validated=False,
        comparison='whole broadened spectrum, all 41 matching momenta; no interpolation',
        energy_window=[-3.25, 5.5], couplings={})
    summary = json.loads((args.map/'summary.json').read_text())
    for coupling in grid['couplings']:
        rows = summary[str(coupling)]
        assert len(rows) == 41
        d = np.load(args.map/f'lambda{coupling:.2f}_map.npz')
        ref = np.load(args.reference/f'lambda{coupling:.2f}_map.npz')
        assert d['A'].shape == (3, 41, 701)
        assert np.isfinite(d['A']).all() and (d['A'] >= 0).all()
        assert np.isfinite(d['bootstrap_16']).all() and np.isfinite(d['bootstrap_84']).all()
        assert np.all(d['bootstrap_16'] <= d['bootstrap_84'])
        np.testing.assert_array_equal(d['k'], ref['k'])
        np.testing.assert_array_equal(d['energy'], ref['energy'])
        np.testing.assert_allclose([r['k'] for r in rows], ref['k'], rtol=0, atol=1e-12)
        errors = []
        for ie, eta in enumerate(d['eta']):
            jr = int(np.flatnonzero(np.isclose(ref['eta'], eta))[0])
            values = np.trapezoid(abs(ref['A'][jr]-d['A'][ie]), d['energy'], axis=1) / np.trapezoid(ref['A'][jr], d['energy'], axis=1)
            errors.append(dict(eta=float(eta), relative_l1=values.tolist(),
                minimum=float(values.min()), maximum=float(values.max()), median=float(np.median(values))))
        cv = [float(np.mean(r['cv']['folds'], axis=0)[r['cv']['selected']]) for r in rows]
        report['couplings'][str(coupling)] = dict(comparison_k=d['k'].tolist(), errors=errors,
            cv=cv, cv_max=max(cv), cv_min=min(cv),
            alpha_boundaries=sum(r['cv']['boundary'] for r in rows),
            maximum_moment_residual=max(abs(x) for r in rows for x in r['fit']['moment_residuals']),
            maximum_training_chi2=max(r['fit']['chi2_per_mode'] for r in rows))
    args.out.mkdir(parents=True, exist_ok=False)
    (args.out/'summary.json').write_text(json.dumps(report, indent=2)+'\n')
    (args.out/'audit_source.py').write_bytes(Path(__file__).read_bytes())
    print(json.dumps({k: v for k, v in report.items() if k != 'couplings'}, indent=2))


if __name__ == '__main__':
    main()
