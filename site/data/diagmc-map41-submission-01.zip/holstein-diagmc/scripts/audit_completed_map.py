"""Read-only audit of completed chains and post-selection comparison at exact shared k."""
from __future__ import annotations
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
out = ROOT/'results/map_audit_01'
out.mkdir(exist_ok=False)
base = ROOT/'results/map_diagmc_01'
provenance = json.loads((base/'provenance.json').read_text())
assert provenance['complete']
for name, digest in provenance['inputs'].items():
    path = Path(name)
    path = path if path.is_absolute() else ROOT/path
    assert sha256(path.read_bytes()).hexdigest() == digest
for name, digest in provenance['sources'].items():
    assert sha256((base/'source'/name).read_bytes()).hexdigest() == digest
runs = []
for file in sorted((ROOT/'results/map_data_01').glob('ik*/lambda*/run.json')):
    r = json.loads(file.read_text())
    assert r['complete']
    for name in ['blocks.csv', 'rb_blocks.csv']:
        assert (file.parent/name).read_bytes().count(b'\n') == r['blocks']+1
    runs.append(r)
assert len(runs) == 136 and len({r['seed'] for r in runs}) == 136
summary = json.loads((base/'summary.json').read_text())
report = dict(captured_utc=datetime.now(timezone.utc).isoformat(),
    chains=len(runs), complete_chains=sum(r['complete'] for r in runs),
    production_steps=sum(r['blocks']*r['steps_per_block'] for r in runs),
    cap_attempts=sum(r['cap_attempts'] for r in runs),
    source_and_input_hashes_verified=True, raw_block_counts_verified=True,
    spectral_resolution_validated=False,
    comparison='whole broadened spectrum, at exactly matching momenta only; no interpolation',
    energy_window=[-3.25, 5.5], couplings={})
for coupling in [.25, .5]:
    rows = summary[str(coupling)]
    assert len(rows) == 17
    d = np.load(base/f'lambda{coupling:.2f}_map.npz')
    ref = np.load(ROOT/f'results/reference_map_01/lambda{coupling:.2f}_map.npz')
    assert d['A'].shape == (3, 17, 701)
    assert np.isfinite(d['A']).all() and (d['A'] >= 0).all()
    assert np.isfinite(d['bootstrap_16']).all() and np.isfinite(d['bootstrap_84']).all()
    np.testing.assert_allclose(d['k'], np.linspace(0, np.pi, 17), rtol=0, atol=1e-12)
    np.testing.assert_array_equal(d['energy'], ref['energy'])
    pairs = []
    for i, k in enumerate(d['k']):
        match = np.flatnonzero(np.isclose(ref['k'], k, rtol=0, atol=1e-12))
        if len(match): pairs.append((i, int(match[0])))
    assert len(pairs) == 9
    errors = []
    for ie, eta in enumerate(d['eta']):
        jr = int(np.flatnonzero(np.isclose(ref['eta'], eta))[0])
        values = []
        for im, ir in pairs:
            reference, candidate = ref['A'][jr, ir], d['A'][ie, im]
            values.append(float(np.trapezoid(abs(reference-candidate), d['energy']) /
                                np.trapezoid(reference, d['energy'])))
        errors.append(dict(eta=float(eta), relative_l1=values,
            minimum=min(values), maximum=max(values), median=float(np.median(values))))
    cv = [float(np.mean(r['cv']['folds'], axis=0)[r['cv']['selected']]) for r in rows]
    report['couplings'][str(coupling)] = dict(
        comparison_k=[float(d['k'][i]) for i, _ in pairs], errors=errors,
        cv=cv, cv_max=max(cv), cv_min=min(cv),
        alpha_boundaries=sum(r['cv']['boundary'] for r in rows),
        maximum_moment_residual=max(abs(x) for r in rows for x in r['fit']['moment_residuals']),
        maximum_training_chi2=max(r['fit']['chi2_per_mode'] for r in rows))
jobs = subprocess.check_output(['sacct', '-X', '-j',
    '20826452,20826455,20825985,20825973,20826180',
    '--format=JobID,JobName,Partition,State,Elapsed,ExitCode,Start,End,NodeList', '-P'],
    text=True).splitlines()
keys = jobs[0].split('|')
report['jobs'] = [dict(zip(keys, row.split('|'))) for row in jobs[1:] if row]
assert all(r['State'] == 'COMPLETED' and r['ExitCode'] == '0:0' for r in report['jobs'])
(out/'summary.json').write_text(json.dumps(report, indent=2)+'\n')
(out/'audit_source.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps(report, indent=2))
