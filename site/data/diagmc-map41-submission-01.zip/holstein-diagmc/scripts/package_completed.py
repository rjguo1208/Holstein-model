"""Package completed numerical work, keeping the published earlier snapshots intact."""
from hashlib import sha256
import json
from pathlib import Path
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SITE = ROOT.parent/'Holstein-model'
common = []
for folder in ['src', 'scripts', 'tests']:
    common += [p for p in (ROOT/folder).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
common += list(ROOT.glob('*.py'))+list(ROOT.glob('*.md'))+[ROOT/'Makefile']
packages = {
    'diagmc-map-completed-01.zip': ['map_diagmc_01', 'map_audit_01', 'map_jobs_01.json'],
    'diagmc-completed-03.zip': ['k0_02', 'spectral_data_02', 'mass_direct_02',
        'spectral_04', 'report_02_completed', 'reference_curvature_02',
        'reference_spectral_01', 'quality_02.json', 'jobs_02.json'],
}
for coupling in [.25, .5]:
    packages[f'diagmc-map-raw-lambda{coupling:.2f}.zip'] = [
        str(p.relative_to(ROOT/'results')) for p in (ROOT/'results/map_data_01').glob(
            f'ik*/lambda{coupling:.2f}*')]
records = []
for name, folders in packages.items():
    files = [] if 'map-raw-' in name else list(common)
    if name == 'diagmc-map-completed-01.zip':
        # Conditional block summaries reproduce continuation; keep raw chains
        # in two coupling-specific archives below GitHub's individual-file cap.
        for point in (ROOT/'results/map_data_01').glob('ik*'):
            files += list(point.glob('*.json'))
            files += [p for folder in ['conditional', 'source']
                      for p in (point/folder).rglob('*')
                      if p.is_file() and '__pycache__' not in p.parts]
    for folder in folders:
        path = ROOT/'results'/folder
        files += ([p for p in path.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
                  if path.is_dir() else [path])
    files = sorted(set(files))
    target = SITE/'site/data'/name
    temporary = target.with_suffix('.tmp')
    with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        for file in files:
            z.write(file, Path('holstein-diagmc')/file.relative_to(ROOT))
    if temporary.stat().st_size >= 95_000_000:
        raise ValueError(f'Split {name} before publishing; it exceeds 95 MB')
    with zipfile.ZipFile(temporary) as z:
        assert z.testzip() is None
    temporary.replace(target)
    record = dict(file=name, files=len(files), bytes=target.stat().st_size,
                  sha256=sha256(target.read_bytes()).hexdigest())
    records.append(record)
    print(json.dumps(record), flush=True)
(SITE/'site/data/completed-archives.json').write_text(json.dumps(records, indent=2)+'\n')
