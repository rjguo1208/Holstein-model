"""Prepare the exact VED momentum grid, copying only identical measured points."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import shutil
import numpy as np

ROOT = Path(__file__).resolve().parents[1]


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT/'results/map_data_41_01')
    args = parser.parse_args()
    old = ROOT/'results/map_data_01'
    reference = ROOT/'results/reference_map_01'
    coupling_values = [.25, .5]
    grid = np.load(reference/'lambda0.25_map.npz')['k']
    np.testing.assert_array_equal(grid, np.load(reference/'lambda0.50_map.npz')['k'])
    assert len(grid) == 41
    np.testing.assert_allclose(grid, [np.pi*i/40 for i in range(41)], rtol=0, atol=1e-12)
    measured = []
    old_seeds = set()
    for point in sorted(old.glob('ik*')):
        runs = [json.loads(p.read_text()) for p in sorted(point.glob('lambda*/run.json'))]
        assert len(runs) == 8 and all(r['complete'] for r in runs)
        k = runs[0]['k']
        assert all(r['k'] == k for r in runs)
        for r in runs:
            assert r['t'] == r['omega'] == 1 and r['mu'] == -2.8
            assert (r['tau_max'], r['bins'], r['max_order']) == (12, 96, 96)
            assert (r['blocks'], r['steps_per_block'], r['rb_thin']) == (240, 100000, 100)
            old_seeds.add(r['seed'])
        measured.append((k, point))
    assert len(measured) == 17 and len(old_seeds) == 136
    offset = 300_000_000
    points, seeds = [], []
    for i, k in enumerate(grid):
        matches = [p for kp, p in measured if abs(kp-k) < 1e-12]
        assert len(matches) <= 1
        record = dict(index=i, k=float(k), mode='reuse' if matches else 'new')
        if matches:
            record['source'] = str(matches[0].relative_to(ROOT))
            record['original_index'] = int(matches[0].name[2:])
            record['file_hashes'] = {str(p.relative_to(matches[0])): sha256(p.read_bytes()).hexdigest()
                for p in sorted(matches[0].rglob('*')) if p.is_file()}
        else:
            planned = [17011+1009*chain+160_000_000+round(lam*100)*100_000+i*1_000_000+offset
                       for lam in coupling_values for chain in range(4)]
            record['seeds'] = planned
            seeds.extend(planned)
        points.append(record)
    assert sum(p['mode'] == 'reuse' for p in points) == 9
    assert len(seeds) == len(set(seeds)) == 256 and not (set(seeds) & old_seeds)
    args.out.mkdir(parents=True, exist_ok=False)
    for p in points:
        if p['mode'] == 'reuse':
            # Preserve original run names, metadata, and random seeds byte for byte.
            shutil.copytree(ROOT/p['source'], args.out/f'ik{p["index"]:03d}')
    manifest = dict(created_utc=datetime.now(timezone.utc).isoformat(),
        grid_source=str(reference.relative_to(ROOT)), points=points,
        couplings=coupling_values, k_points=len(grid), reused_points=9, new_points=32,
        chains_per_coupling_and_point=4, production_steps_per_chain=24_000_000,
        total_chains=328, new_chains=256, reused_chains=72,
        new_production_steps=6_144_000_000, total_production_steps=7_872_000_000,
        seed_offset=offset, old_seeds_disjoint_from_new=True,
        reuse='Exact measured k only; copied raw chains and conditional blocks without changes',
        reference_used_for='Momentum coordinates only; VED spectra do not enter continuation',
        prepare_source_sha256=sha256(Path(__file__).read_bytes()).hexdigest())
    (args.out/'grid_manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
    (args.out/'prepare_source.py').write_bytes(Path(__file__).read_bytes())
    (args.out/'new_indices.txt').write_text('\n'.join(str(p['index']) for p in points if p['mode'] == 'new')+'\n')
    print(json.dumps({k: v for k, v in manifest.items() if k != 'points'}, indent=2))


if __name__ == '__main__':
    main()
