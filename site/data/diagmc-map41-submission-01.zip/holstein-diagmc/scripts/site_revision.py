"""Publishable plain HTML source and scientific figures for the V2 results."""
import argparse
import csv
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser()
parser.add_argument('--mass',default='results/mass_direct_02_initial')
parser.add_argument('--spectra',default='results/spectral_03')
parser.add_argument('--figures',default='results/report_02')
parser.add_argument('--site',default='../Holstein-model')
parser.add_argument('--sampling-status',choices=['pending','complete'],required=True)
args=parser.parse_args();site=(ROOT/args.site).resolve()
mass=json.loads((ROOT/args.mass/'summary.json').read_text())
spectra=json.loads((ROOT/args.spectra/'summary.json').read_text())
old=json.loads((ROOT/'results/spectral_02/summary.json').read_text())
def table(headers,rows,caption):
    return '<div class="table-scroll"><table><caption>'+caption+'</caption><thead><tr>'+''.join('<th scope="col">'+s+'</th>' for s in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join(('<th scope="row">'+s+'</th>') if i==0 else '<td>'+s+'</td>' for i,s in enumerate(row))+'</tr>' for row in rows)+'</tbody></table></div>'
def figure(name,alt,caption,width=1000,height=650):
    return f'<figure><div class="figure-scroll data"><img src="results/{name}.svg" width="{width}" height="{height}" alt="{alt}"></div><figcaption>{caption}</figcaption><p class="figure-links"><a href="results/{name}.svg">SVG</a><a href="results/{name}.pdf">PDF</a></p></figure>'
rows=[];massrows=[];spectralrows=[];syntheticrows=[];controls=[];observables=[]
for lam in [.25,.5]:
    m=mass[str(lam)];s=spectra[str(lam)];g=m['ground']['primary'];p=m['primary']
    ref=m['reference_curvature'][-1]['mass_ratio']
    rows.append([str(lam),f"{g['E']:.7f} ± {g['E_error']:.7f}",f"{g['Z']:.5f} ± {g['Z_error']:.5f}",f"{p['mass_ratio']:.5f} ± {p['mass_ratio_error']:.5f}"])
    massrows.append([str(lam),f"{ref:.8f}",f"{abs(p['mass_ratio']-ref)/p['mass_ratio_error']:.2f}σ",f"{p['chi2_per_dof']:.2f}",f"{m['window_span'][0]:.6f}–{m['window_span'][1]:.6f}"])
    spectralrows.append([str(lam),f"{100*old[str(lam)]['rest_l1_vs_reference']:.1f}%",f"{100*s['tikhonov_errors']['rest']:.1f}%",f"{100*s['som_errors']['rest']:.1f}%"])
    syntheticrows.append([str(lam),f"{100*s['clean_tikhonov_errors']['rest']:.1f}%",f"{100*s['clean_som_errors']['rest']:.1f}%"])
    for c in m['sampling_controls']:
        f=c['fit'];controls.append([str(lam),c['control'],f"{f['mass_ratio']:.5f} ± {f['mass_ratio_error']:.5f}"])
    observables.append(dict(coupling=lam,E=g['E'],E_error=g['E_error'],Z=g['Z'],Z_error=g['Z_error'],
        direct_mass_ratio=p['mass_ratio'],direct_mass_ratio_error=p['mass_ratio_error'],
        reference_mass_k_to_zero=ref,tikh_rest_l1=s['tikhonov_errors']['rest'],som_rest_l1=s['som_errors']['rest']))
status=('本页展示已完成的既有数据重分析。新增的每个耦合8条长虚时链、16条谱数据链已提交集群，'
        '本次发布时仍在排队；图表未把这些尚未完成的采样算入结果。两批作业成功后会自动进行后处理并保存新的报告。'
        if args.sampling_status=='pending' else
        '新增独立链与后处理已完成；本页使用合并后的长虚时结果及新谱数据。')
common_resolution=[]
for point in spectra['0.25']['resolution']:
    eta=point['eta'];other=next(p for p in spectra['0.5']['resolution'] if p['eta']==eta)
    if max(point['tikh_rest'],point['som_rest'],other['tikh_rest'],other['som_rest'])<.1:
        common_resolution.append(eta)
if common_resolution:
    width=min(common_resolution)
    resolution_text=rf'在本轮扫描的展宽中，要让两种方法、两种耦合的非相干谱误差都低于10%，最小需要到 \(\eta={width:g}t\)。'
    if width>=.6:resolution_text+='这已是很粗的频率分辨率，不能据此确认单个声子侧带的峰宽或细峰结构。'
else:
    resolution_text='本轮扫描的展宽范围内，两种方法尚未同时把两种耦合的非相干谱误差降至10%以下。'
resolution_text+=r'加大展宽不等于在原来的 \(\eta=0.25t\) 分辨率下完成目标；展宽也不是物理寿命。'
target_text=('两种方法均通过本轮10%的积分误差目标；单个峰位与宽度仍需独立检验。' if
             all(s[m+'_errors']['rest']<.1 for s in spectra.values() for m in ['tikhonov','som']) else
             '尚有参数或方法未达到10%目标，精细谱形仍需进一步检验。')
lead=('直接质量估计量显著减小了统计误差；谱重建增加了非线性极点和随机优化比较。'+target_text)
mass_assessment=(r'\(\lambda=0.25\) 的拟合 \(\chi^2/\mathrm{dof}\) 偏高且窗口结果有漂移，这些影响需要结合独立链进一步检验。'
                 if mass['0.25']['primary']['chi2_per_dof']>1.5 else
                 '主结果应结合不同窗口、时间分箱和独立批次共同判断；统计误差并非系统误差上界。')
html=r'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="Holstein bare DiagMC 的直接质量估计量、精确极点延拓、随机优化谱重建和可分辨精度检验。">
<title>1D Holstein：DiagMC 改进与验证</title>
<link rel="stylesheet" href="assets/katex/katex.min.css"><link rel="stylesheet" href="assets/style.css"></head>
<body><a class="skip-link" href="#content">跳到正文</a><main id="content">
<header><p><a href="index.html">返回 DiagMC 理论与费曼图</a></p><h1>1D Holstein<br>DiagMC 改进与验证</h1>
<p>零温、单电子、无限晶格。更新：2026-09-18。</p>
<p><a href="spectral-map.html">查看 k–能量谱函数图</a>：实际 DiagMC 重建、独立 VED 参考与精度检查。</p>
<p><strong>@LEAD@</strong></p>
<p>@STATUS@</p></header>
<section id="parameters"><h2>参数与基态结果</h2>
\[t=\omega_0=\hbar=a=1,\qquad \lambda=\frac{g^2}{2t\omega_0}=0.25,\;0.5.\]
<p>能量相对于无电子、无声子的真空；\(\varepsilon_k=-2t\cos k\)，自由质量 \(m_0=1/(2t)=0.5\)。
采样包含交叉图，内部动量连续分布在布里渊区。辅助参数 \(\mu\) 与虚时截止不改变零温的物理模型。</p>
@GROUND@
<p>± 为一个统计标准误差。\(E_0,Z_0\) 来自长虚时的相关拟合；质量来自本轮直接估计量。
质量的窗口依赖另列，不能把更小的统计误差当成全部计算误差。</p>
<p>下载：<a href="data/observables-v2.csv">本轮主要结果 CSV</a> · <a href="data/summary-v2.json">完整分析 JSON</a> ·
<a href="data/@UPDATE_ARCHIVE@">本轮代码、分析数据与报告</a> · <a href="data/holstein-diagmc.zip">首轮完整代码与原始块数据</a>。
复现本轮重分析时，将两个 ZIP 解压到同一目录；原始采样没有被参考解替换。</p></section>
<section id="mass"><h2>从图的动量导数直接计算质量</h2>
<p>已有采样保存了每段电子动量 \(p_i\) 和传播时间对应的导数统计量：</p>
\[J=\sum_i2t\sin p_i\,\Delta\tau_i,\qquad K=\sum_i2t\cos p_i\,\Delta\tau_i.\]
<p>在 \(k=0\) 的反射对称性下，长虚时满足</p>
\[\langle K-J^2\rangle_\tau\simeq\frac{\tau}{m^*}-\left.\partial_k^2\ln Z_k\right|_{k=0}.\]
<p>拟合斜率得到逆质量，保留来自 \(Z_k\) 曲率的截距。主窗口为 \(\tau\in[8,20]\)，时间箱合并至宽度1。
均匀时间箱的指数加权只改变这一渐近直线的截距；绘图时按图点的原始箱宽转换截距。
方法背景见 <a href="https://amslaurea.unibo.it/id/eprint/22104/1/ragni-diagrammatic_monte_carlo_study_of_the_holstein_polaron.pdf#page=67">Ragni 的直接估计量</a>。</p>
<p>统计误差取三种块长和逐链删除 jackknife 的最大值。还扫描时间分箱、协方差收缩和拟合窗口。
首轮色散拟合为 1.1496 ± 0.0076、1.3543 ± 0.0161，与直接结果相容。</p>
@MASS@
<p>此处 VED 用 \(k=0,0.01,0.02,0.04\) 与14/16代变分空间检查真正的 \(k\to0\) 曲率。
首轮参考质量使用较大的动量网格，本轮参考更接近导数极限。
@MASS_ASSESS@</p>
@MASS_FIG@
@CONTROLS@
<p>控制计算用于检验辅助参数、虚时截止和阶数截止的影响；它们没有被挑选来替换主结果。
同组窗口和主拟合共享数据，不能当成多个独立测量。</p></section>
<section id="forward"><h2>先检查虚时数据，再判断谱重建</h2>
\[\mathcal G_\mu(0,\tau)=\int d\omega\,A(0,\omega)e^{-(\omega-\mu)\tau}.\]
<p>将独立 VED 谱用同一精确箱积分核正向变换，与真实传播子比较。
条件积分估计的相邻虚时点高度相关，图中的逐点误差不能当成独立误差；分析保留数据协方差。</p>
@FORWARD_FIG@
<p>基准还包括无噪声传播子，以及8组协方差与实际数据匹配的带噪声合成实验。
真实数据的模型选择先完成，之后才读取 VED 谱；合成实验用于检验方法。</p>
@SYNTHETIC@
<p>这里“无噪声”是指输入均值取自参考传播子，仍用实际协方差、真实数据已选定的正则化强度或优化长度来评估。
它检验有限分辨率下的表示和正则化偏差，不保证含噪声数据同样准确。</p></section>
<section id="spectrum"><h2>精确基态极点与两种延拓方法</h2>
\[A(0,\omega)=Z_0\delta(\omega-E_0)+A_{\mathrm{rest}}(0,\omega).\]
<p>新版 Tikhonov 对极点能量进行精确非线性剖面优化，保留独立长虚时运行给出的相关 \(E_0,Z_0\) 误差。
原来 \(\lambda=0.25\) 的约 \(-2.71\sigma\) 极点偏移，本轮为约 \(@POLE_SHIFT@\sigma\)。</p>
<p>SOM 变体用连续矩形表示非负谱，随机改变中心、宽度和矩形数量，重新优化面积，并平均多个近最优解。
它借鉴 <a href="https://arxiv.org/pdf/cond-mat/9910025#page=25">Mishchenko 等的随机优化思想</a>，但更新和带协方差目标并非原文实现的逐项复现。
谱支持允许基态之上的束缚激发权重，没有预先删去单声子阈值以下的全部谱。</p>
\[M_0=1,\qquad M_1=\varepsilon_0,\qquad M_2=\varepsilon_0^2+g^2.\]
<p>两种方法均检查未展宽谱的精确矩。正则化强度或优化长度由独立链留出预测选择；参考谱不参与选择。</p>
@SPECTRAL@
<p>表中为去掉基态极点后的相对 \(L^1\) 误差，在 \(\eta=0.25t\)、\(\omega/t\in[-3.25,7]\) 下统一比较。
<strong>@TARGET_TEXT@</strong>
随机优化没有在所有参数下带来改善，也不能因为一个重建更接近参考就反过来据此调参。</p>
@SPECTRA_FIG@
<p>蓝色范围来自32次链内块 bootstrap，同时传播独立 \(E_0,Z_0\) 的相关误差，每次重新交叉验证选择正则化参数。
它是16–84%的经验范围，包含参数选择的波动，但不包括所有谱参数化偏差；SOM 解之间的波动也不是后验置信区间。</p>
@VALIDATION_FIG@
</section><section id="resolution"><h2>实际能分辨到什么程度</h2>
@RESOLUTION_FIG@
<p>@RESOLUTION_TEXT@</p>
</section><section id="next"><h2>新增采样与后续计算</h2>
<p>@STATUS@</p>
<p>自动后处理将合并长虚时数据、重复两种延拓、块重采样和分辨率检查，并写出明确的验收结果。
只有既定质量目标和 \(\eta=0.25t\) 的谱目标通过后，才启动 \(\lambda=0.75,1.0,1.5\) 的采样与独立参考。
降低声子频率和外部声子扇区属于更后的阶段，目前没有把这些计算标记为完成。</p>
<p>验证包括图权重的独立动量差分、非零截距的质量提取、矩形谱的双重积分、精确极点与谱矩、展宽归一化，
以及随机优化的自由电子极限。完整原始块、源文件快照、输入哈希与运行状态保存在下载包中。</p></section>
<footer><p><a href="index.html">理论与 LaTeX/TikZ 费曼图</a> · <a href="https://github.com/rjguo1208/Holstein-model">网站源文件</a></p></footer>
</main></body></html>'''
replace={
 'UPDATE_ARCHIVE':'diagmc-completed-03.zip' if args.sampling_status=='complete' else 'diagmc-update-02.zip',
 'STATUS':status,
 'LEAD':lead,'MASS_ASSESS':mass_assessment,
 'POLE_SHIFT':f"{spectra['0.25']['tikhonov']['prior_shift_sigma']:+.2f}",
 'TARGET_TEXT':target_text,'RESOLUTION_TEXT':resolution_text,
 'GROUND':table([r'\(\lambda\)',r'\(E_0/t\)',r'\(Z_0\)',r'直接 \(m^*/m_0\)'],rows,'实际 bare DiagMC 结果；系统误差检查见下文'),
 'MASS':table([r'\(\lambda\)',r'VED \(m^*/m_0\)','与参考差异',r'\(\chi^2/\mathrm{dof}\)','窗口6–10的质量范围'],massrows,'直接质量的精度与窗口检查'),
 'CONTROLS':table([r'\(\lambda\)','控制项',r'\(m^*/m_0\)'],controls,'独立控制运行：mu 下移、tau 截止增大、order 上限减半'),
 'SPECTRAL':table([r'\(\lambda\)','首轮 Tikhonov','新版 Tikhonov','SOM 变体'],spectralrows,'相同展宽下的非相干谱误差'),
 'SYNTHETIC':table([r'\(\lambda\)','Tikhonov','SOM 变体'],syntheticrows,'无噪声输入下的非相干谱误差，η=0.25t'),
 'MASS_FIG':figure('direct-mass','直接质量估计量相对于VED斜率的偏差，以及改变拟合窗口后的质量。','上：扣除参考斜率后的图估计量。下：不同拟合下限的质量；窗口共享原始数据。'),
 'FORWARD_FIG':figure('forward-check','虚时数据与VED正向传播子、两种谱重建的逐点残差。','残差使用各点标准误差归一化。相邻点相关，因此灰色区域不是同时置信带。',height=340),
 'SPECTRA_FIG':figure('spectra-v2','新版Tikhonov与SOM谱和独立VED比较，完整谱与非相干部分分开显示。','上：完整谱；下：去掉基态极点后的谱。黑虚线为独立VED，蓝线为Tikhonov，橙线为SOM变体。'),
 'VALIDATION_FIG':figure('validation-v2','独立链留出预测分数随正则化强度和随机优化长度变化。','参数按留出预测分数选择，虚线表示所选值。'),
 'RESOLUTION_FIG':figure('resolution','非相干谱误差随显示展宽变化，虚线为百分之十的比较目标。','不同展宽下的事后精度评估；不能用更大的展宽冒充更高分辨率。',height=340)
}
for key,value in replace.items():html=html.replace('@'+key+'@',value)
(site/'src/results.html').write_text(html)
for name in ['direct-mass','spectra-v2','forward-check','resolution','validation-v2']:
    for suffix in ['svg','pdf']:shutil.copyfile(ROOT/args.figures/f'{name}.{suffix}',site/'site/results'/f'{name}.{suffix}')
(site/'site/data/summary-v2.json').write_text(json.dumps(dict(mass=mass,spectra=spectra,sampling_status=args.sampling_status),indent=2)+'\n')
with (site/'site/data/observables-v2.csv').open('w',newline='') as f:
    writer=csv.DictWriter(f,fieldnames=list(observables[0]));writer.writeheader();writer.writerows(observables)
print('Prepared',site/'src/results.html')
