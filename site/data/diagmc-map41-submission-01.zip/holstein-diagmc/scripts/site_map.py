"""Publish a plain, source-labeled reference spectral map with reproducible data."""
from __future__ import annotations
import argparse
import gzip
from hashlib import sha256
import json
from pathlib import Path
import re
import shutil
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--reference', type=Path, default=ROOT/'results/reference_map_01')
parser.add_argument('--site', type=Path, default=ROOT.parent/'Holstein-model')
parser.add_argument('--jobs', type=Path, default=ROOT/'results/map_jobs_01.json')
parser.add_argument('--diagmc', type=Path)
parser.add_argument('--audit', type=Path, default=ROOT/'results/map_audit_01/summary.json')
args = parser.parse_args()
s = json.loads((args.reference/'summary.json').read_text())
jobs = json.loads(args.jobs.read_text())
eta_index = s['eta'].index(.25)
rows = []
for coupling in s['couplings']:
    errors = []
    for lower, upper in [(14, 16), (16, 18)]:
        selected = [r for r in s['convergence'] if
                    r['coupling'] == coupling and r['lower'] == lower and r['upper'] == upper]
        errors.append(max(r['relative_l1'][eta_index] for r in selected))
    steps = max(r['step_relative_l1'][eta_index] for r in s['records']
                if r['coupling'] == coupling and 'step_relative_l1' in r)
    rows.append(f'<tr><th scope="row">{coupling:g}</th><td>{errors[0]:.3%}</td>'
                f'<td>{errors[1]:.3%}</td><td>{steps:.2e}</td></tr>')
plots = args.site/'site/results'
data = args.site/'site/data'
for kind in ['linear', 'log']:
    for suffix in ['svg', 'pdf', 'png']:
        source = args.reference/f'figures/spectral-map-{kind}.{suffix}'
        shutil.copyfile(source, plots/source.name)
downloads = []
for coupling in s['couplings']:
    name = f'lambda{coupling:.2f}_map.npz'
    shutil.copyfile(args.reference/name, data/name)
    d = np.load(args.reference/name, allow_pickle=False)
    kk, ww = np.meshgrid(d['k'], d['energy'], indexing='ij')
    csv = data/f'lambda{coupling:.2f}_map_eta0.25.csv.gz'
    with gzip.open(csv, 'wt') as f:
        np.savetxt(f, np.column_stack([kk.ravel(), (kk/np.pi).ravel(), ww.ravel(),
                                      d['A'][eta_index].ravel()]),
                   delimiter=',', header='k,k_over_pi,energy_over_t,t_A_eta0.25',
                   comments='', fmt='%.12g')
    downloads.append(f'<li>λ={coupling:g}：<a href="data/{name}">完整 NPZ</a> · '
                     f'<a href="data/{csv.name}">主图 CSV（gzip）</a></li>')
shutil.copyfile(args.reference/'summary.json', data/'spectral-map-validation.json')
shutil.copyfile(args.jobs, data/'spectral-map-jobs.json')
moment_error = max(max(abs(v) for v in r['moment_residuals']) for r in s['records'])
html = r'''<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="1D Holstein 的 k–能量谱函数图，清楚标注 VED/Lanczos 参考来源、绝对谱强度、展宽和 DiagMC 采样状态。">
<title>1D Holstein：谱函数图 A(k,ω)</title>
<link rel="stylesheet" href="assets/katex/katex.min.css"><link rel="stylesheet" href="assets/style.css"></head>
<body><a class="skip-link" href="#content">跳到正文</a><main id="content">
<header><p><a href="results.html">DiagMC 结果与验证</a> · <a href="index.html">理论与费曼图</a></p>
<h1>1D Holstein 谱函数图</h1>
<p>横轴为动量路径，纵轴为能量，颜色表示谱函数的绝对强度。零温、单电子、无限晶格；更新：2026-09-18。</p>
<p><strong>当前完整图来自独立的 VED/Lanczos 参考计算。</strong>
现有完整 DiagMC 谱只覆盖 \(k=0\)；沿整条路径的新增 DiagMC 采样已提交，@QUEUE_STATUS@。
这张参考图用于展示结构和后续对照，不能作为 DiagMC 已完成的结果。</p></header>
<section id="map"><h2>线性色标：比较绝对强度</h2>
\[t=\omega_0=\hbar=a=1,\qquad
\lambda=\frac{g^2}{2t\omega_0}=0.25,\;0.5,\qquad
k:\Gamma(0)\longrightarrow X(\pi).\]
<p>每种耦合独立计算41个均匀动量点，能量范围为 \(\omega/t\in[-3.25,5.5]\)。
所有动量使用同一个真空能量零点，左右两图共用色标；没有对每个动量单独归一化，也没有平移动量列的能量。
色块直接对应计算的动量点，未沿动量方向平滑插值。</p>
<figure><div class="figure-scroll data"><img src="results/spectral-map-linear.svg" width="1020" height="540"
alt="两种耦合的VED参考谱函数图：横轴从Gamma的k等于0到X的k等于pi，纵轴为相对真空的能量，右侧共同线性色标为t乘以谱函数。"></div>
<figcaption>VED 16代变分空间，178617个基矢；显示展宽 \(\eta=0.25t\)。
亮色表示较大的谱权重。它包含准粒子峰和其余谱重，不只是基态色散线。</figcaption>
<p class="figure-links"><a href="results/spectral-map-linear.svg">SVG</a>
<a href="results/spectral-map-linear.pdf">PDF</a><a href="results/spectral-map-linear.png">PNG</a></p></figure>
</section><section id="convention"><h2>谱函数和展宽的定义</h2>
\[A(k,\omega)=\sum_\nu
\bigl|\langle \nu,k|c_k^\dagger|\mathrm{vac}\rangle\bigr|^2
\delta\!\left(\omega-E_\nu(k)\right),\qquad
\int_{-\infty}^{\infty}A(k,\omega)\,d\omega=1.\]
\[A_\eta(k,\omega)=\int d\omega'\,A(k,\omega')
\frac{\eta/\pi}{(\omega-\omega')^2+\eta^2}
=-\frac{1}{\pi}\operatorname{Im}G^R(k,\omega+i\eta).\]
<p>图中颜色为无量纲的 \(tA_\eta\)。\(\eta\) 是洛伦兹线形的半高半宽，本图对应全宽 \(0.5t\)。
它控制显示分辨率，不等于极化子的物理衰减率。
有限绘图窗口没有收集全部谱重和洛伦兹尾，因此没有把图窗内的每列积分强行调成1。</p>
</section><section id="weak"><h2>对数色标：查看较弱的谱重</h2>
<figure><div class="figure-scroll data"><img src="results/spectral-map-log.svg" width="1020" height="540"
alt="与主图相同的谱函数数据，改用对数色标显示较弱的谱强度，色标刻度仍为谱函数本身。"></div>
<figcaption>与主图使用完全相同的数据，只改变颜色映射；色标刻度仍是 \(tA_\eta\)，不是其对数值。
色标下限为 \(10^{-3}\)，更小的值显示为最深色。较弱的颜色还包括展宽产生的尾部，不能全部视为新的激发。</figcaption>
<p class="figure-links"><a href="results/spectral-map-log.svg">SVG</a>
<a href="results/spectral-map-log.pdf">PDF</a><a href="results/spectral-map-log.png">PNG</a></p></figure>
</section><section id="validation"><h2>参考图的数值检查</h2>
<p>变分空间按 Bonča 等提出的无限晶格基底构造。有限空间把连续谱表示为离散极点，再按同一展宽求和；
见 <a href="https://arxiv.org/abs/cond-mat/9812252">Bonča、Trugman 与 Batistić（1999）</a>。
主图使用16代；14与16代在全部41个动量点比较，16与18代在 \(0,\pi/4,\pi/2,3\pi/4,\pi\) 五点比较。</p>
\[\delta_A(k)=
\frac{\int_{\omega_{\min}}^{\omega_{\max}}|A_{\eta,N_h}(k,\omega)-A_{\eta,N_h'}(k,\omega)|\,d\omega}
{\int_{\omega_{\min}}^{\omega_{\max}}A_{\eta,N_h'}(k,\omega)\,d\omega}.\]
<div class="table-scroll"><table><caption>相同图窗、η=0.25t：检查点中的最大相对积分差异</caption>
<thead><tr><th scope="col">λ</th><th scope="col">14→16代，41点</th>
<th scope="col">16→18代，5点</th><th scope="col">400→800步，检查点</th></tr></thead>
<tbody>@CONVERGENCE@</tbody></table></div>
<p>Lanczos 不保存全部向量作重正交化；在上述五个动量点、各个变分空间，以800步检查400步结果。
这些差异支持当前展宽下的参考图稳定性，但不是对无限基底精确解的严格误差上界，也不保证更窄展宽的细结构。</p>
\[M_0=1,\qquad M_1=-2t\cos k,\qquad M_2=4t^2\cos^2k+g^2.\]
<p>所有计算均检验了展宽前的三个谱矩；最大绝对残差为 @MOMENT_ERROR@。
洛伦兹展宽后的高阶矩不用于这项检验。</p>
</section><section id="diagmc"><h2>对应的 DiagMC 谱图</h2>
\[\mathcal G_\mu(k,\tau)=\int d\omega\,A(k,\omega)e^{-(\omega-\mu)\tau}.\]
<p>已新增17个均匀动量点的采样流程；两种耦合、每点4条独立链，
每链2400万生产步，共136条链。计算保存条件虚时估计量和相关块数据；
采样结束后自动执行非负谱延拓、独立链交叉验证、块重采样，并输出相同坐标的谱图。</p>
<p>全路径延拓不强行指定每个动量的孤立基态极点，也不将 VED 图作为输入。
它使用精确的有限时间箱积分核和未展宽谱矩。
当前流程中的 \(\eta=0.25t\) 与 \(1t\) 两种显示分辨率均需事后验证，不能从已有 \(k=0\) 检查推断整条路径都已达到同样精度。</p>
<p>发布时状态：@JOB_TEXT@。新增计算成功后会在计算目录自动生成数据与报告，网页结果需验证后再更新。</p>
</section><section id="download"><h2>数据和复现</h2>
<ul>@DOWNLOADS@</ul>
<p>NPZ 内的 <code>A</code> 轴顺序为 <code>(eta, k, energy)</code>，
展宽数组为 <code>[0.15, 0.25, 0.5, 1.0]</code>，每张主图的数据形状为 <code>(41, 701)</code>。
CSV 每行依次是 <code>k, k/π, ω/t, tA</code>；只导出主图的 \(\eta=0.25t\)。</p>
<p><a href="data/spectral-map-validation.json">完整参考检查 JSON</a> ·
<a href="data/spectral-map-jobs.json">采样作业记录</a> ·
<a href="data/diagmc-spectral-map-01.zip">本轮源码、极点和图谱数据</a>。</p>
</section><footer><p><a href="results.html">DiagMC 结果与验证</a> ·
<a href="https://github.com/rjguo1208/Holstein-model">网站源文件</a></p></footer>
</main></body></html>
'''
html = html.replace('@QUEUE_STATUS@', jobs['publication_status_zh'])
html = html.replace('@CONVERGENCE@', ''.join(rows)).replace('@DOWNLOADS@', ''.join(downloads))
html = html.replace('@MOMENT_ERROR@', f'{moment_error:.2e}')
html = html.replace('@JOB_TEXT@', jobs['description_zh'])
if args.diagmc is not None:
    audit = json.loads(args.audit.read_text())
    assert json.loads((args.diagmc/'provenance.json').read_text())['complete']
    assert audit['complete_chains'] == audit['chains'] == 136
    real_downloads = []
    for coupling in s['couplings']:
        source = args.diagmc/f'lambda{coupling:.2f}_map.npz'
        name = f'diagmc-lambda{coupling:.2f}_map.npz'
        shutil.copyfile(source, data/name)
        d = np.load(source, allow_pickle=False)
        kk, ww = np.meshgrid(d['k'], d['energy'], indexing='ij')
        csv = data/f'diagmc-lambda{coupling:.2f}_map_eta0.25.csv.gz'
        with gzip.open(csv, 'wt') as stream:
            np.savetxt(stream, np.column_stack([kk.ravel(), (kk/np.pi).ravel(),
                ww.ravel(), d['A'][0].ravel()]), delimiter=',', comments='',
                header='k,k_over_pi,energy_over_t,t_A_eta0.25', fmt='%.12g')
        real_downloads.append(f'<li>DiagMC，λ={coupling:g}：<a href="data/{name}">NPZ 与 bootstrap 范围</a> · '
                              f'<a href="data/{csv.name}">主图 CSV（gzip）</a></li>')
    figures = {}
    for eta in [.25, 1.]:
        for kind in ['linear', 'log']:
            stem = f'diagmc-map-eta{eta:g}-{kind}'
            for suffix in ['svg', 'pdf', 'png']:
                shutil.copyfile(args.diagmc/f'eta{eta:g}/spectral-map-{kind}.{suffix}',
                                plots/f'{stem}.{suffix}')
            figures[eta, kind] = (
                f'<figure><div class="figure-scroll data"><img src="results/{stem}.svg" '
                f'width="1020" height="540" alt="实际bare DiagMC的17动量点谱函数图，展宽为{eta:g}t，'
                f'使用{kind}色标。结果仍为初步重建。"></div>'
                f'<figcaption>实际 DiagMC 虚时数据的非负谱延拓；η={eta:g}t。'
                '每列来自独立采样的动量点。</figcaption><p class="figure-links">'
                f'<a href="results/{stem}.svg">SVG</a><a href="results/{stem}.pdf">PDF</a>'
                f'<a href="results/{stem}.png">PNG</a></p></figure>')
    checks = []
    for coupling in ['0.25', '0.5']:
        case = audit['couplings'][coupling]
        e025 = next(e for e in case['errors'] if e['eta'] == .25)
        e1 = next(e for e in case['errors'] if e['eta'] == 1)
        checks.append(f'<tr><th scope="row">{coupling}</th>'
            f'<td>{e025["minimum"]:.1%}–{e025["maximum"]:.1%}</td>'
            f'<td>{e1["minimum"]:.1%}–{e1["maximum"]:.1%}</td>'
            f'<td>{case["cv_max"]:.1f}</td></tr>')
    lead = r'''<p><strong>17个动量点的 bare DiagMC 采样和谱图生成均已完成；精细谱仍未通过稳定性验证。</strong>
两种耦合共136条链、32.64亿生产步，均正常结束。下方先展示实际 DiagMC 重建，随后给出独立 VED 参考。
较粗展宽下的整体谱形更稳定；窄峰和声子侧带的精细结构仍需检验。</p></header>'''
    html = re.sub(r'<p><strong>当前完整图.*?</p></header>', lambda _: lead,
                  html, count=1, flags=re.S)
    section = r'''<section id="diagmc-map"><h2>实际 DiagMC 谱图：η=0.25t</h2>
<p>保持默认参数 \(t=\omega_0=1\)、\(\lambda=0.25,0.5\)，路径为 \(\Gamma(0)\to X(\pi)\)。
17个动量点分别采样和延拓，不沿动量方向插值。横轴为 \(k\)，纵轴为相对真空的 \(\omega/t\)，
左右色标统一为 \(tA_\eta(k,\omega)\)。</p>
@REAL_FINE@
<p>中、高动量处的一些峰在相邻动量列之间不稳定，不能据此确认新的物理激发。
图已生成并不代表这些窄峰已达到定量精度；本轮保留这些原始重建差异。</p>
<p><a href="results/diagmc-map-eta0.25-log.svg">同数据的对数色标 SVG</a> ·
<a href="results/diagmc-map-eta0.25-log.pdf">PDF</a>。</p>
<h2>较粗分辨率：η=t</h2>
@REAL_COARSE@
<p>这里只增加显示展宽，没有重新拟合或更换原始数据。较平滑的整体谱形不能用于判断单个声子侧带的峰宽。</p>
<h2>已完成的精度检查</h2>
<p>与参考图完全重合的9个动量 \(k/\pi=0,1/8,\ldots,1\) 逐点比较，保持相同能量网格、图窗和展宽，
不插值参考谱。下表为这些点上<strong>整条谱</strong>的相对积分误差范围：</p>
<div class="table-scroll"><table><caption>事后比较；VED 不参与 DiagMC 谱的拟合和参数选择</caption>
<thead><tr><th scope="col">λ</th><th scope="col">η=0.25t</th><th scope="col">η=t</th>
<th scope="col">最大留出预测分数</th></tr></thead><tbody>@REAL_CHECKS@</tbody></table></div>
<p>该误差包含基态峰，不能与结果页中去掉基态峰后的“非相干谱误差”混用。
大动量处的留出预测分数偏高，提示统计量或协方差评估仍需改进。
9点比较没有验证其余8个动量，也不构成逐频率误差上界。</p>
<p>原始块数、源代码和输入哈希均已检查；136条链均完成，阶数上限拒绝次数为0。
未展宽的 \(M_0,M_1,M_2\) 最大残差小于 \(10^{-9}\)。
NPZ 保存8次块 bootstrap 的16–84%经验范围；它不包含全部谱参数化偏差。</p>
<p><a href="data/diagmc-map-audit.json">完整检查 JSON</a> ·
<a href="data/diagmc-map-completed-01.zip">DiagMC 源码、传播子块数据与谱图</a>。</p>
<p>原始逐链文件：<a href="data/diagmc-map-raw-lambda0.25.zip">λ=0.25</a> ·
<a href="data/diagmc-map-raw-lambda0.50.zip">λ=0.5</a>。按耦合分包；完整审计时与主数据包解压到同一目录。</p>
<ul>@REAL_DOWNLOADS@</ul>
<p>DiagMC NPZ 的 <code>A</code> 形状为 <code>(3, 17, 701)</code>，
轴为 <code>(eta, k, energy)</code>，展宽数组为 <code>[0.25, 0.5, 1.0]</code>。</p>
</section>'''
    section = (section.replace('@REAL_FINE@', figures[.25, 'linear'])
        .replace('@REAL_COARSE@', figures[1., 'linear'])
        .replace('@REAL_CHECKS@', ''.join(checks))
        .replace('@REAL_DOWNLOADS@', ''.join(real_downloads)))
    html = html.replace('<section id="map">', section+'<section id="map">', 1)
    html = html.replace('线性色标：比较绝对强度', '独立 VED 参考：相同展宽下比较', 1)
    completed = r'''</section><section id="diagmc"><h2>采样与后处理已完成</h2>
\[\mathcal G_\mu(k,\tau)=\int d\omega\,A(k,\omega)e^{-(\omega-\mu)\tau}.\]
<p>采样作业20826452在 highmem 的 b000 节点完成，用时3分02秒；后处理作业20826455在同一分区和节点完成，
用时2分29秒，均正常退出。每个耦合、每个动量4条独立链，每链2400万生产步。</p>
<p>全路径延拓使用精确时间箱积分核、协方差、未展宽谱矩和独立链交叉验证，
不强行指定每个动量的孤立基态极点，也不将 VED 谱作为输入。谱仍标为初步结果。</p>
</section><section id="download"><h2>参考数据和复现</h2>'''
    html = re.sub(r'</section><section id="diagmc">.*?<section id="download"><h2>数据和复现</h2>',
                  lambda _: completed, html, count=1, flags=re.S)
    shutil.copyfile(args.audit, data/'diagmc-map-audit.json')
(args.site/'src/spectral-map.html').write_text(html)
print('Generated spectral-map.html and copied figures/data')
