# Spectral map: k path × energy × absolute spectral density

The map page now includes **actual bare DiagMC continuation** at 17 momenta and
a separate 41-point VED/Lanczos reference. No k=0 spectrum was copied/interpolated
to other momenta. All 136 chains and the analysis completed on highmem b000.
Fine spectral resolution is still unvalidated: at the nine exactly shared k
values, full-spectrum L1 errors reach 37.2% / 43.6% for lambda=.25/.5 at eta=.25t.
At eta=t the maxima are 2.57% / 5.11%, which only supports the coarse envelope.
See results/map_audit_01/summary.json for checks and completed job records.

## Completed reference

- 1D infinite lattice, zero temperature, one electron added to the phonon vacuum.
- t=omega0=1, lambda=g²/(2 t omega0)=0.25 and 0.5.
- 41 independently calculated points on Gamma→X (0≤k≤pi), a=1.
- Energy is relative to the same electron/phonon vacuum at every k.
- 701 energy values between -3.25t and 5.5t.
- NPZ A axis order: (eta, k, energy), eta=[.15,.25,.5,1.].
- Main figure: Lorentzian eta=.25t (half width), common absolute t*A color scale.
- Secondary figure: same data, logarithmic color mapping; labels are t*A.
- No per-column normalization, k smoothing, or k-dependent energy shift.
- Main basis Nh16 (178617 states); Nh14 compared at all 41 momenta and Nh18 at
  0, pi/4, pi/2, 3pi/4, pi. Lanczos uses 400 steps, or 800 at those check points.

At eta=.25t, the largest full-spectrum relative L1 change over the plotted
energy window is 0.1020% / 0.0956% (Nh14→16, lambda .25/.5) and
0.0253% / 0.0366% (Nh16→18 at the five check points). The largest 400→800-step
change is 3.26e-11. Unbroadened M0, M1, M2 residuals are below 1.20e-14.
These are convergence diagnostics, not rigorous error bounds on the exact
infinite-space spectrum or certificates for narrower broadening.

The finite plotted window omits spectral weight and Lorentzian tails. Higher
moments of the Lorentzian-broadened density are not used as sum-rule checks.

~~~bash
# This archive includes the exact numerical reference routines under source/.
./scripts/python.sh scripts/reference_map.py \
  --project results/reference_map_01/source --out results/reference_map_reproduced
./scripts/python.sh scripts/plot_spectral_map.py \
  results/reference_map_reproduced/lambda0.25_map.npz \
  results/reference_map_reproduced/lambda0.50_map.npz \
  --out results/reference_map_reproduced/figures
~~~

scripts/python.sh is the local environment wrapper; elsewhere use your Python
with numpy, scipy, matplotlib (and pytest for tests), or set HOLSTEIN_PYTHON.
The archived reference sources are identical to the routines hashed in
results/reference_map_01/provenance.json. The additional package directory
contains copies plus an import-only __init__.py for standalone reproduction.

## Actual DiagMC map acquisition

Sampling job 20826452 and dependent analysis job 20826455 were submitted on
2026-09-18. Their publication-time queue state is in results/map_jobs_01.json.
An initial 17-element job array was rejected by the submit-count limit; a single
4-CPU job processing the momenta successively was accepted. The earlier k=0
improvement jobs remain active.

On 2026-09-18, at the user's request, both spectral-map jobs (20826452 and
20826455) were moved to highmem using scontrol update. Their job IDs, resource
requests and afterok dependency are unchanged. Both map submission scripts now
default to the highmem partition. The partition transition and verified Slurm
state are recorded in results/map_jobs_01.json.

The new calculation uses 17 uniform momenta, two couplings, four independent
chains per point, 24 million production steps per chain (136 chains total).
Each chain saves 240 blocks, tau_max=12, 96 bins, mu=-2.8, max_order=96,
conditional time integration every 100 steps. Output:
results/map_data_01/ikNNN/conditional/lambda*_ikNNN_base/.

Unlike the long-time E/Z suite, this suite does not force an isolated-pole
exponential fit at large k. map_continuation.py fits a nonnegative **full**
spectrum on a uniform grid, with the exact bin-integrated Laplace kernel,
full covariance, and unbroadened M0/M1/M2. The lower support bound
-2t-g²/omega0 follows from completing the oscillator square in the
single-electron sector. It uses no VED input or E(k),Z(k) prior.

The regularization scan includes zero and 1e-9 through 1e3. Selection minimizes
the mean prediction score of independent held-out chains. Blocks are grouped
in fours, time bins in pairs; tau≤8 enters the fit. Eight within-chain block
bootstrap replicates repeat parameter selection. This is an initial uncertainty
check, not a complete resolution study. The saved output marks
spectral_resolution_validated=false; moments and agreement in imaginary time
alone do not validate real-frequency structure. Insufficient covariance rank
raises an error instead of reporting spurious precision.

~~~bash
make
sbatch --account=YOUR_ACCOUNT --partition=YOUR_PARTITION scripts/map_data.slurm
# Submit map_finish.slurm with afterok dependency on the returned sampling job.
./scripts/python.sh scripts/continue_map.py \
  --data results/map_data_01 --out results/map_diagmc_01 --points 17 --bootstrap 8
~~~

On success, the dependent job writes NPZ, full diagnostics, and figures at
eta=.25t and 1t. It does not automatically publish unreviewed spectra to the
website. Finite-grid, support, covariance, statistics, and spectral-reference
checks are still required before assigning quantitative all-k accuracy.

## Website and data

scripts/site_map.py copies reference figures/data and generates
../Holstein-model/src/spectral-map.html. Run that repository's npm run build
and npm run check after updating the page. Images are vector SVG/PDF plus PNG
downloads; LaTeX formulas are pre-rendered with HTML/MathML. The existing theory
and DiagMC validation pages link to the map and retain their results.
