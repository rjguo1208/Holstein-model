# DiagMC on the same 41 momenta as VED

The requested grid is k_j = j*pi/40, j=0,...,40, identical to the stored VED
coordinates. Default parameters remain t=omega0=1 and lambda=g^2/(2*t*omega0)
=0.25,0.5. Each coupling and momentum has four independent chains, each with
24 million production steps. The energy grid, continuation method, bootstrap
count and display broadenings are unchanged.

Only nine points of the completed 17-point map match this grid. Their old/new
indices are (0,0), (2,5), (4,10), (6,15), (8,20), (10,25), (12,30), (14,35),
(16,40). Raw chains, conditional blocks, source snapshots and metadata are
copied byte for byte. Their original internal run names and seeds are retained.
The other eight old momenta are not relabeled or interpolated into the new grid.

The remaining 32 points need 256 new chains: 6,144,000,000 new production steps.
The final 41-point map uses 328 chains and 7,872,000,000 production steps, including
the 72 reused chains. A fresh seed offset of 300,000,000 makes every planned new
seed unique and disjoint from all 136 old map seeds. The grid manifest records
the exact match map, planned seeds and hashes of every reused file.

## Submitted jobs and status

- Sampling: 20829123, highmem, 4 CPUs, 8 GB, 30 minute limit.
- Continuation and audit: 20829124, highmem, 1 CPU, 4 GB, 2 hour limit;
  dependency afterok:20829123.
- Both were submitted on 2026-09-18 at 23:29:27 America/Indianapolis (UTC-4).
- At submission, sampling was PENDING because nodes were reserved for
  maintenance; analysis was PENDING on its dependency. The cluster reservation
  covers 2026-09-18 23:30 through 2026-09-20 21:00 America/Indianapolis.
  This reservation end is not a promised job start time.

The website continues to show the completed 17-point DiagMC map until actual
41-point output is available and checked. More k points improve momentum
sampling; they do not establish better real-frequency resolution. Fine-spectrum
validation remains open.

## Workflow and reproduction

The submission archive stores its grid and job records under plans/ so it does
not create an incomplete results/map_data_41_01 directory on extraction.
For a fresh reconstruction, unpack the earlier completed map archive, its two
raw-chain archives and the VED reference archive, then unpack this new source
archive last. Build the executable with make and use your scientific Python
environment (set HOLSTEIN_PYTHON if needed).

~~~bash
./scripts/python.sh scripts/prepare_dense_map.py
sbatch --account=YOUR_ACCOUNT --partition=highmem scripts/map_dense_data.slurm
# Use the returned sampling ID as JOB_ID in the next command.
sbatch --account=YOUR_ACCOUNT --partition=highmem \
  --dependency=afterok:JOB_ID scripts/map_dense_finish.slurm
~~~

Preparation refuses to overwrite an existing suite. The sampling job processes
only new_indices.txt and uses four concurrent chains, staying within the
highmem submission-count limit. The dependent job reconstructs all 41 momenta
and automatically runs audit_dense_map.py. The audit requires 328 completed,
uniquely seeded chains, consistent parameters and block counts, unchanged reused
files, and verified source/input hashes. It also requires identical VED and
DiagMC coordinate arrays and compares the spectra at all 41 points, after
continuation and parameter selection; VED spectral values do not enter the fit.

Outputs are results/map_data_41_01, results/map_diagmc_41_01 and
results/map_audit_41_01. Final map arrays have shape (3,41,701), with axes
(eta,k,energy) and eta=[0.25,0.5,1.0]. Energy remains relative to the common vacuum,
the color scale is absolute t*A, and the plotter applies no k interpolation.
Successful calculation creates local spectra and figures; website publication
requires checking those outputs first.
